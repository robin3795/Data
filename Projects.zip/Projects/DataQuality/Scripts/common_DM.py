#!c:/Python27/python.exe
# Author: Robin Li (Inegrated from Vertica and NameScan projects)
# Created Date: Nov 16 2016

import string
import os
import re
import xml.etree.ElementTree as etree
import json
import datetime
import pyodbc                                # For DB connection
import requests.packages.urllib3             # For HDFS
requests.packages.urllib3.disable_warnings() # Disable HDFS access warning information
import paramiko                              # For SFTP access
import hashlib                               # For MD5 check

def HDFS_download(UName_hdfs, Pwd_hdfs, HDFSFile, LocalDir):
    '''
    (str, str, str, str)-> None
    Download one single file from HDFS to local directory in stream
    >>> HDFS_download('*****', '*****', '/dev/up20/data/dm/year/month/day/filename','../HDFS')
    '''
    filename = os.path.basename(HDFSFile)
    localpath = os.path.join(LocalDir, filename)    
    url = 'https://gueulvahal002.saifg.rbc.com:8443/gateway/default/webhdfs/v1' + HDFSFile + '?op=OPEN'
    with open(localpath, 'wb') as handle:
        response = requests.get(url, auth=(UName_hdfs, Pwd_hdfs), stream=True, verify=False)

        if response.status_code == 200:
            for block in response.iter_content(1024):
                handle.write(block)


def hive_fetch_data(myDSN, sql_query, row_num=100):
    """
    (str, str, int) -> list of tuples
    >>> hive_fetch_data("HortonWorksHiveDSN", "Show Tables;", 1000)
    [('arrangement', ),('avro_arrangement', ),('avro_party_additional_info', ),('avro_party_address', ),('avro_party_arrangement', )]
    >>> hive_fetch_data("HortonWorksHiveDSN", "SELECT ArrangementId FROM aml_up20_qa.Transaction WHERE ArrangementId='00004519020078729062';", 1000)
    """
    conn = pyodbc.connect('DSN=' + myDSN, autocommit = True, ansi = True)
    cursor = conn.cursor()
    rs=cursor.execute(sql_query)
    rows = rs.fetchmany(row_num)
    return rows


def get_db_connection_info(xmlfile):
    '''
    (str)->dict
    Parse xml file and return dictionary of database connection information
    >>> get_connection_info('C:\\path\\to\\filename.xml')
    {'User': 'DDWV01', 'Url': 'server:8080:DB'}
    '''
    con_dic = {}
    t = etree.parse(xmlfile)
    r = t.getroot()
    alist = r.findall('property')
    for i, element in enumerate(alist):
        x = alist[i].find('name').text
        y = alist[i].find('value').text
        if ('Url' in x):
            con_dic['Url'] = y
        elif ('User' in x):
            con_dic['User'] = y
        elif ('Password' in x):
            con_dic['Password'] = y
        elif ('schema' in x):
            con_dic['schema'] = y
        elif ('Port' in x):
            con_dic['Port'] = y
        elif ('Database' in x):
            con_dic['Database'] = y
        elif('Driver' in x):
            con_dic['Driver'] = y
    if ('@' in con_dic['Url']):
        con_dic['Url'] = (re.sub(r"\:(?=[^:]*$)", "/", con_dic['Url'])).split("@")[1]
    return con_dic


def SFTP_Get_Files(serverHost,serverPort,userName,keyFile,remotepath,localpath):
    '''
    (str, str, str, str, str, str)-> None
    Download one single file from SFTP server to local directory in stream
    >>> HDFS_download('*****', '*****', '/dev/up20/data/dm/year/month/day/filename','../HDFS')
    '''
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    serverPort=int(serverPort)
    #ssh.connect(sftpURL, username=sftpUser, password=sftpPass)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)

    if (len(files)>1):
        files.sort()
    item = files[-1]
    sftp_name="sftp_"+item
    localfile =  os.path.join (localpath,sftp_name)
    remotefile = remotepath+'/'+item
    ftp.get(remotefile,localfile)              

    ftp.close()
    ssh.close()
    return sftp_name


def psvify(value_list, clip_columns=0):
    '''Converts a list into psv values
    >>psvify([('a','1'),('b','2')])
    '''
    psvfied = []
    clip_columns=int(clip_columns)
    for values in value_list:
        if(clip_columns>0):
            values = values[:-clip_columns]
        joined = '|'.join(str(i) for i in values)
        #Future: joined = '|'.join(str(j) for i,j in enumerate(values) and j not in clip_columns)
        psvfied.append(joined)
    return psvfied


def get_HDFS_file_line_count(UName_hdfs, Pwd_hdfs, HDFSFile):
    '''
    (str, str, str)-> Int
    Return specific HDFS file line number.
    >>> get_HDFS_file_line_count('*****', '*****', '/dev/up20/data/dm/year/month/day/filename')
    '''
    url = 'https://gueulvahal002.saifg.rbc.com:8443/gateway/default/webhdfs/v1' + HDFSFile +'?op=OPEN'
    line_count = 0
    response = requests.get(url, auth=(UName_hdfs, Pwd_hdfs), stream=True, verify=False)
    if response.status_code == 200:
        #for block in response.iter_content(1024):
        line_point = response.iter_lines()
        for line in line_point:
            line_count += 1
    return line_count


def get_csv_file_line_count_with_condition(File, condition=''):
    '''
    (str, str, str)-> Int
    Return specific local csv file line number whith condition(column,operation,value).
    For example, 'column,!=,A' means the value of column is not equal A.
    >>> get_csv_file_line_count_with_condition('/dev/up20/data/dm/year/month/day/filename','Column,!=,Value')
    '''
    line_count = -1
    if condition != '':
        list_condition = condition.split(',')
    with open(File) as fileobject:
        for line in fileobject:
            if '"' in line:
                all_quoted_strings = re.findall(r'"([^"]*)"',line)
                for any_quoted_string in all_quoted_strings:
                    temp_string = any_quoted_string.replace(',','CommaInQuote')
                    line = line.replace(any_quoted_string,temp_string)
                columns = line.split(',')
                columns = map(lambda x :  x.replace('CommaInQuote',','),columns)
                columns = map(lambda x :  x.replace('"',''),columns)
            else:
                columns = line.split(',')
            if line_count == -1:
                column_num = len(columns)
                if condition != '':
                    if list_condition[0] in columns:
                        index_keyword = columns.index(list_condition[0])
                line_count = 0
            else:
                if len(columns) != column_num:
                    Error_message = 'Data Error in line '+str(line_count+1)+' !'
                    print (Error_message)
                    print('There is '+str(len(columns))+' columns in this line, not '+str(column_num)+'\n')
                    print (line)
                if condition != '':
                    if list_condition[1] == '==':
                        if columns[index_keyword] == list_condition[2]:
                            line_count += 1
                    if list_condition[1] == '!=':
                        if columns[index_keyword] != list_condition[2]:
                            line_count += 1
                else:
                    line_count += 1
    return line_count


# direct use: hashlib.md5('Passw0rd').hexdigest()
# hash.update(arg)
#    Update the hash object with the string arg. Repeated calls are equivalent to a single call with the concatenation of all the arguments: m.update(a); m.update(b) is equivalent to m.update(a+b).
#    Changed in version 2.7: The Python GIL is released to allow other threads to run while hash updates on data larger than 2048 bytes is taking place when using hash algorithms supplied by OpenSSL.
def get_md5_checksum(filePath):
    '''
    >>>md5_checksum('c:\\testdata\\test.file')
    '''
    with open(filePath, 'rb') as fh:
        m = hashlib.md5()
        while True:
            data = fh.read(8192)
            if not data:
                break
            m.update(data)
        return m.hexdigest()



