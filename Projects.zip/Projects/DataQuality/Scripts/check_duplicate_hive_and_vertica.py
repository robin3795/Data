import pyodbc

def check_dup_vertica(Server1, DB1, Port1, User, Password, SQLQuery1):
    '''
    (str, str, str)-> list
    PREREQUISITE: pyodbc
    USE: This function connect to vertica database, run SQL Queries and return query record
    '''
    
    pyodbc.autocommit = True
    connH = pyodbc.connect("DSN=Hive1", autocommit=True)
    vcursorH = connH.cursor()
    
    #connstr = "DRIVER=Vertica;Server=vertica-ucs-uat1.devfg.rbc.com;DATABASE=CSTOVBU1;PORT=5433;UID=" + User + ";PWD=" + Password
    connstr = "DRIVER=Vertica;Server="+Server1+";DATABASE="+DB1+";PORT="+Port1+";UID=" + User + ";PWD=" + Password        
    conn = pyodbc.connect(connstr)
    vcursor = conn.cursor()
    rs = vcursor.execute(SQLQuery1)
    row = vcursor.fetchall()
    #for i in range(len(row)):
    #   print(row[i])
    #return row
    
    print 'Test start===================================='
    for i in range(0, len(row)):
        print  'No. ' + str(i)+'th record-------------------------------'
        #print(row[i])
        #print row[i][3]
        print 'Entity Name is:'
        print row[i][2]
        print 'DupCount is:'
        print row[i][4]
        #list_UDDI= row[i][3].split('&')
        newstr = row[i][3].replace("=", "='")
        newstr2 = newstr.replace("&", "' and ")
        newstr3 = newstr2+"'"
        #print 'new:'+ newstr3
        #list_UDDI= newstr3.split(' ')
        #print list_UDDI

        '''    
        if row[i][2]== 'Transaction':
            print'This record is Transaction'
            QAquery = "select transactionid, arrangementsystemsourceid, arrangementid, transactiondate, count(*) as count from aml_up20_pilot.Transaction where "+newstr3 + " group by transactionid, arrangementsystemsourceid, arrangementid, transactiondate having count(*)>1 "
            
        elif row[i][2]== 'AML_UP20_PILOT.Arrangement' or row[i][2]== 'Arrangement':
            print 'This record is Arrangement'
            #QAquery = 'select capturedate,systemsourceid, arrangementid, loadseq,  count(*) as count from aml_up20_pilot.Arrangement where arrangementid = '100254481' and capturedate ='2016-08-01' and systemsourceid = '104' and loadseq = '2041155067' group by capturedate,systemsourceid, arrangementid , loadseq' having count(*)>1               
            QAquery = "select arrangementid, systemsourceid, accountserviceid, capturedate, count(*) as count from aml_up20_pilot.Arrangement where "+newstr3 + " group by capturedate,systemsourceid, arrangementid , accountserviceid having count(*)>1"
        
        print QAquery
    ''' 
        if row[i][1]== 'Silver_layer_file':
            print 'RepoType is Silver_layer_file'
            if row[i][2]== 'Transaction':
                print'This record is Transaction'
                QAquery = "select transactionid, arrangementsystemsourceid, arrangementid, transactiondate, count(*) as count from Transaction where "+newstr3 + " group by transactionid, arrangementsystemsourceid, arrangementid, transactiondate having count(*)>1 "
                
            elif row[i][2]== 'AML_UP20_PILOT.Arrangement' or row[i][2]== 'Arrangement':
                print 'This record is Arrangement'
                #QAquery = 'select capturedate,systemsourceid, arrangementid, loadseq,  count(*) as count from aml_up20_pilot.Arrangement where arrangementid = '100254481' and capturedate ='2016-08-01' and systemsourceid = '104' and loadseq = '2041155067' group by capturedate,systemsourceid, arrangementid , loadseq' having count(*)>1               
                #QAquery = "select arrangementid, systemsourceid, accountserviceid, capturedate, count(*) as count from Arrangement where "+newstr3 + " group by capturedate,systemsourceid, arrangementid , accountserviceid having count(*)>1"
                QAquery = "select arrangementid, systemsourceid, capturedate, count(*) as count from Arrangement where "+newstr3 + " group by capturedate,systemsourceid, arrangementid  having count(*)>1"
            print QAquery
            rs2 = vcursorH.execute(QAquery)
            row2 = vcursorH.fetchall()
        elif row[i][1]== 'Vertica':
            print 'RepoType is Vertica'
            if row[i][2]== 'Transaction':
                print'This record is Transaction'
                QAquery = "select transactionid, arrangementsystemsourceid, arrangementid, transactiondate, count(*) as count from aml_up20_pilot.Transaction where "+newstr3 + " group by transactionid, arrangementsystemsourceid, arrangementid, transactiondate having count(*)>1 "
                
            elif row[i][2]== 'AML_UP20_PILOT.Arrangement' or row[i][2]== 'Arrangement':
                print 'This record is Arrangement'
                #QAquery = 'select capturedate,systemsourceid, arrangementid, loadseq,  count(*) as count from aml_up20_pilot.Arrangement where arrangementid = '100254481' and capturedate ='2016-08-01' and systemsourceid = '104' and loadseq = '2041155067' group by capturedate,systemsourceid, arrangementid , loadseq' having count(*)>1               
                #QAquery = "select arrangementid, systemsourceid, accountserviceid, capturedate, count(*) as count from aml_up20_pilot.Arrangement where "+newstr3 + " group by capturedate,systemsourceid, arrangementid , accountserviceid having count(*)>1"
                QAquery = "select arrangementid, systemsourceid,  capturedate, count(*) as count from aml_up20_pilot.Arrangement where "+newstr3 + " group by capturedate,systemsourceid, arrangementid  having count(*)>1"
            print QAquery            
            rs2 = vcursor.execute(QAquery)
            row2 = vcursor.fetchall()
            
        #rs2 = vcursor.execute(QAquery)
        #row2 = vcursor.fetchall()
        #for j in range(len(row2)):
        print 'QA query return the duplicate count is:'       
        print row2[0][4]
        if row2[0][4] == row[i][4]:
            print' Found matched '
        else:
            print' Mismatched dup number found!'
        print 'next record-------------------------------'
        print
        
    vcursor.close()
    conn.close()
    vcursorH.close()
    connH.close()


if __name__ == '__main__':
    # Replace ***** with your username and ##### with your password
    query1 = "select * from AML_UP20_PILOT.DuplicationCheckResult where checkdate > '2017-01-12 10:00:00' limit 10"
    
    #query1 = "SELECT count(*) From aml_up20_qa_pilot.transaction"
    Server='vertica-ucs-uat1.devfg.rbc.com'
    DATABASE='CSTOVBU1'
    PORT= '5433'
    myrecord = check_dup_vertica(Server, DATABASE, PORT, "QUP20VERTSRV01PILOT","UP20PT_Q1",query1)

    #for i in range(len(myrecord)):
        #print(myrecord[i])