#!c:/Python27/python.exe
# Robin Li
# Develop for split large output GFF file
# Oct 26, 2016

import random

def split_file(inputfile, split_lines):
    n=0
    with open(inputfile) as infile:
        line_num=0
        outfile=open('dummy_file','w')
        for line in infile:
            if (line_num == n*split_lines):
                outfile.close()    
                n=n+1
                outputfilename=inputfile+'_'+str(n)
                outfile=open(outputfilename,'w')
            print line
            outfile.write(line)
            line_num = line_num+1
    outfile.close()

def get_random_samples(inputfile, sample_num):
    total_lines = sum(1 for line in open(inputfile)
    for i in 1,sample_num:
        random_number = random(1, total_lines)

split_file('c:\Temp\sample.dat',20)
