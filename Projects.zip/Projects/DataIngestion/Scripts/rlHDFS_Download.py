#!c:/Python27/python.exe
# Originated by Mohammad M. Bhuiyan
# Robin Li June 29 2016

import os
##import requests
##from requests.packages.urllib3.exceptions import InsecureRequestWarning
##requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import json
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

def HDFS_list_dir(UName_hdfs, Pwd_hdfs, HDFSDir, Type='FILE'):
    '''
    (str, str, str, str)-> None
    This function will enlist files or Dirs or both inside a directory in HDFS and return the list.
    Use 'FILE' for file only list, 'DIRECTORY' for Dir only list and 'BOTH' for both file and Dir list
    '''

    url = 'https://gueulvahal002.saifg.rbc.com:8443/gateway/default/webhdfs/v1' + HDFSDir + '?op=LISTSTATUS'

    Type = Type.upper()   # Type can be case-insensitive  R. 2016-07-04
    alist = []
    response = requests.get(url, auth=(UName_hdfs, Pwd_hdfs), verify=False)
    if response.status_code == 200:
        j = response.json()

        for i in range(len(j['FileStatuses']['FileStatus'])):
            if Type == 'FILE':
                if j['FileStatuses']['FileStatus'][i]['type'] == 'FILE':
                    alist.append((j['FileStatuses']['FileStatus'][i]['pathSuffix']))
            elif Type == 'DIRECTORY':
                if j['FileStatuses']['FileStatus'][i]['type'] == 'DIRECTORY' and j['FileStatuses']['FileStatus'][i]['pathSuffix'] != '.Trash':
                    alist.append((j['FileStatuses']['FileStatus'][i]['pathSuffix']))
            elif Type == 'BOTH':
                if j['FileStatuses']['FileStatus'][i]['pathSuffix'] != '.Trash':
                    alist.append((j['FileStatuses']['FileStatus'][i]['pathSuffix']))
            else:
                pass
    return alist


def HDFS_getpath(UName_hdfs, Pwd_hdfs, HDFSStartDir):
    '''
    (str, str, str)->list
    Return list of file paths after a starting directory (HDFSStartDir).
    "HDFS_Dirpath_after" function used as Helper function. depth could be upto 100.
    Level of depth can be increased to any number e.g. 500 without affecting performance.
    As soon as it searched all the Dir, it stop searching, therefore the large number
    of depth will not affect the performance.
    >>> HDFS_getpath('/dev/project/data/dm', '******', '******')
    '''
    folistodd = []
    folisteven = []
    tmplist = []
    filelist = []

    folistodd = HDFS_Dirpath_after(UName_hdfs, Pwd_hdfs, HDFSStartDir)
    filelist = HDFS_listpath(UName_hdfs, Pwd_hdfs, HDFSStartDir, 'FILE')

    for i in range(100):
        if folistodd != []:
            folisteven = []
            for itm in folistodd:
                folisteven += HDFS_Dirpath_after(UName_hdfs, Pwd_hdfs, HDFSStartDir, itm)
                tmplist = HDFS_listpath(UName_hdfs, Pwd_hdfs, HDFSStartDir + itm, 'FILE') # Helper Function
                filelist += tmplist
            if folisteven == []:
                return filelist

        if folisteven !=[]:
            folistodd = []
            for itm in folisteven:
                folistodd += HDFS_Dirpath_after(UName_hdfs, Pwd_hdfs, HDFSStartDir, itm)
                tmplist = HDFS_listpath(UName_hdfs, Pwd_hdfs, HDFSStartDir + itm, 'FILE') # Helper Function
                filelist += tmplist
            if folistodd == []:
                return filelist      

def HDFS_Dirpath_after(UName_hdfs, Pwd_hdfs, HDFSStartDir, NextDir=""):
    '''
    (str, str, str, [str])->list
    Return Dir paths starting from a directory path (HDFSStartDir) and going to the branch specified by NextDir.
    If NextDir is empty, then it only give the Dir paths at the starting directory(HDFSStartDir)
    This function is used in "HDFS_getpath" function to find files path in different directory after a starting directory.
    >>> HDFS_Dirpath_after('*****', '*****', '/dev/project/data/sourceID', '/2016')
    >>> HDFS_Dirpath_after('*****', '*****', '/dev/project/data/sourceID')
    '''
    folist = []
    url = 'https://gueulvahal002.saifg.rbc.com:8443/gateway/default/webhdfs/v1' + HDFSStartDir + NextDir + '?op=LISTSTATUS'
    response = requests.get(url, auth=(UName_hdfs, Pwd_hdfs), verify=False)
    # time.sleep(5)
    if response.status_code == 200:
        j = response.json()
        for k in range(len(j['FileStatuses']['FileStatus'])):
            if j['FileStatuses']['FileStatus'][k]['type'] == 'DIRECTORY' and j['FileStatuses']['FileStatus'][k]['pathSuffix'] != '.Trash':
                folist.append(NextDir + '/' + j['FileStatuses']['FileStatus'][k]['pathSuffix'])
    return folist


def HDFS_listpath(UName_hdfs, Pwd_hdfs, HDFSDir, Type='FILE'):
    '''
    (str, str, str, str)->list
    Return list of path of Dirs or files or both inside a directory. As Type, Use 'FILE' for file,
    'DIRECTORY' for Dir and 'BOTH' for both file and Dir
    >>> HDFS_listpath('****', '****', 'HDFS_Dir', 'FILE')
    '''
    pathlist = []
    mylist = HDFS_list_dir(UName_hdfs, Pwd_hdfs, HDFSDir, Type) # Helper Function
    for itm in mylist:
        pathlist.append(HDFSDir + '/' + itm)
    return pathlist


def path2dirtree(path):
    '''
    >>> path2dirtree('c:\\shared\\data\\SourceID')
    '''
    if not os.path.exists(path):
        alist=[]
        newpath = "..\\"
        alist = path.split("\\")
        for item in alist:
            newpath = newpath + item + "\\"
            if not os.path.exists(newpath):
                os.mkdir(newpath, 0755)


def HDFS_download(UName_hdfs, Pwd_hdfs, HDFSFile, LocalDir):
    '''
    (str, str, str, str)-> None
    Download one single file from HDFS to local directory in stream
    >>> HDFS_download('*****', '*****', '/dev/up20/data/dm/year/month/day/filename','../HDFS')
    '''
    filename = os.path.basename(HDFSFile)
    localpath = os.path.join(LocalDir, filename)    
    url = 'https://gueulvahal002.saifg.rbc.com:8443/gateway/default/webhdfs/v1' + HDFSFile + '?op=OPEN'
    with open(localpath, 'wb') as handle:
        response = requests.get(url, auth=(UName_hdfs, Pwd_hdfs), stream=True, verify=False)

        if response.status_code == 200:
            for block in response.iter_content(1024):
                handle.write(block)


def clone_HDFS_on_local(UName_hdfs, Pwd_hdfs, HDFSDir, LocalDir):
    '''
    (str, str, str, str)-> None
    Retrieve all directories and files in the HDFSDir in HDFS into LocalDir.
    Create directory structure in local machine as per target file path in HDFS. Download the file from HDFS to corresponding local Directory
    >>> clone_HDFS_on_local('******', '******',/dev/AppCode/data/dm, ..\\data\\input\\HDFS')
    '''
    
    fl = HDFS_getpath(UName_hdfs, Pwd_hdfs, HDFSDir)
    
    for item in fl:
        head, tail = os.path.split(item)
        r_subfolder = head.replace(HDFSDir,'') 
        dirpath = LocalDir + r_subfolder.replace('/', '\\')
        path2dirtree(dirpath)        # Create the local subDir if not exist
        HDFS_download(UName_hdfs, Pwd_hdfs, item, dirpath)


def get_HDFS_file_tree(UName_hdfs, Pwd_hdfs, HDFSDir, TargetFile="..\\Data\\FileTtree.txt"):
    '''
    (str, str, str, str)-> None
    Retrieve all directories and files in the HDFSDir in HDFS into LocalDir.
    Create directory structure in local machine as per target file path in HDFS. Download the file from HDFS to corresponding local Directory
    >>> clone_HDFS_on_local('******', '******',/dev/AppCode/data/dm, ..\\data\\input\\HDFS')
    '''
    
    fl = HDFS_getpath(UName_hdfs, Pwd_hdfs, HDFSDir)

    with open(TargetFile,'w') as f:
        for item in fl:
            f.write('%s\n'%item)
    f.close


def download_HDFS_Folder_to_local(UName_hdfs, Pwd_hdfs, HDFSDir, LocalDir):
    '''
    (str, str, str, str)-> None
    Retrieve all directories and files in the HDFSDir in HDFS into LocalDir.
    Create directory structure in local machine as per target file path in HDFS. Download the file from HDFS to corresponding local Directory
    >>> clone_HDFS_on_local('******', '******',/dev/AppCode/data/dm, ..\\data\\input\\HDFS')
    '''
    
    fl = HDFS_listpath(UName_hdfs, Pwd_hdfs, HDFSDir)
    
    for item in fl:
        head, tail = os.path.split(item)
        r_subfolder = head.replace(HDFSDir,'') 
        dirpath = LocalDir + r_subfolder.replace('/', '\\')
        path2dirtree(dirpath)        # Create the local subDir if not exist
        HDFS_download(UName_hdfs, Pwd_hdfs, item, dirpath)

