#!c:/Python27/python.exe
# Joseph(Qiao)Pu 
# 1 Aug. 2016
import xml.etree.ElementTree as ET
import sys
import re
import paramiko
import os
import os.path
import time
import csv

def parse_property_xml(xmlfile):
    tree = ET.parse(xmlfile)
    root = tree.getroot() 
    config_list = []
    sources_list = []
    single_source_list = []
    sourceid = ''
    for property in root.findall('property'):
        name = property.find('name').text
        value = property.find('value').text
        matchObj = re.search('\([^\(]+\)$' , name)
        if matchObj:
            if sourceid !=  matchObj.group():# new sourceid or blank                
                if sourceid != '' : 
                    sources_list.append(single_source_list) #new source id              
                sourceid = matchObj.group()
                single_source_list = []  #initial new list for new source
                single_source_list.append(sourceid)
                single_source_list.append(value)
            else:
                single_source_list.append(value)                
        else:
                config_list.append(value)
                pass
    config_list.append(sources_list)
    return config_list


'''
method to get one files from a remote sftp server path, transfer to the local given path
'''
def SFTPGetFiles(serverHost,serverPort,userName,keyFile,remotepath,localpath):
    ssh = paramiko.SSHClient()

    # automatically add keys without requiring human intervention
    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    
    serverPort=int(serverPort)

    #ssh.connect(sftpURL, username=sftpUser, password=sftpPass)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)

    if (len(files)>1):
        files.sort()
    item = files[-1]
    sftp_name="sftp_"+item
    localfile =  os.path.join (localpath,sftp_name)
    remotefile = remotepath+'/'+item
    ftp.get(remotefile,localfile)              

    ftp.close()
    ssh.close()
    return sftp_name

def SFTPGetAllFiles(serverHost,serverPort,userName,keyFile,remotepath,localpath):
    ssh = paramiko.SSHClient()

    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    
    serverPort=int(serverPort)

    #ssh.connect(sftpURL, username=sftpUser, password=sftpPass)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)

    for f in files:
        localfile =  os.path.join (localpath,f)
        remotefile = remotepath+'/'+f
        ftp.get(remotefile,localfile)
                
    ftp.close()
    ssh.close()


'''
method to remove one specified file in the remote sftp server
'''

def SFTPCleanFile(serverHost,serverPort,userName,keyFile,remotepath,file):
    ssh = paramiko.SSHClient()

    # automatically add keys without requiring human intervention
    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    
    serverPort=int(serverPort)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)
    #print files
    ftp.remove(file)

 
    ftp.close()
    ssh.close()

'''
method to remove all files in the given remotepath
'''
def SFTPCleanAllFile(serverHost,serverPort,userName,keyFile,remotepath):
    ssh = paramiko.SSHClient()

    # automatically add keys without requiring human intervention
    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    
    serverPort=int(serverPort)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)
    #print files    

    for f in files:   
        remotefile = remotepath+'/'+f
        print remotefile
        ftp.remove(remotefile)
        #ftp.get(remotefile,localfile)

    ftp.close()
    ssh.close()



    #file = "/dq5/env/C/600/in/20160728000437_6_Clnt.dat"  #for test remove a single file

    #SFTPGetFiles(serverHost,serverPort,userName,keyFile,remotepath,localpath)
    #SFTPCleanFile(serverHost,serverPort,userName,keyFile,remotepath,file)
    #SFTPCleanAllFile(serverHost,serverPort,userName,keyFile,remotepath)
        
##if __name__ == '__main__':
##    c = parse_property_xml_config('..\Data\properties.xml')
##    d = parse_property_xml_sorce('..\Data\properties.xml')
##    print c
##    for i in d:
##       print i


##if __name__ == '__main__':
##    serverHost = "uafrdd60.saifg.rbc.com"
##    serverPort = 22
##    userName = "yftq52up"
##    keyFile = "../Data/yftq52up"
##    remotepath = "/dq5/env/C/600/in"
##    localpath = "..\Data\SFTP"
##    SFTPGetFiles(serverHost,serverPort,userName,keyFile,remotepath,localpath)

global inputdict
#global inputset
#global inputlist
#global input_index

global outputdict
global outputset
global outputlist
global output_index
global fixlen
#global sharedset
global reportfile


fixlen = 1



def check_output_xml(outputxml, report):    
    outputtree = ET.parse(outputxml)
    outputroot = outputtree.getroot()
    print 
    print '====Begin Check Output xml=========='
    global outputdict
    outputdict = {}
    global outputlist
    outputlist = []
    global output_index
    output_index = []
    j = 0
    for child in outputroot:
        #print child.tag, child.attrib  
        name = child.attrib.get('name') 
        length = child.attrib.get('length')
        value = child.attrib.get('value')
        print name, length, value
        try:    
            dlength= int(length)
            #break
            #outputdict[name]=dlength
            sl = [dlength, j]                        
            outputdict[name]= sl
            print outputdict[name]
            #dict1 = {name:dlength}
            outputlist.append({name:dlength})
            output_index.append(dlength)
            
        except ValueError:
            print 'Output Error! This length in output xml is not a valid int length!' + name 
            global reportfile
            reportfile = report 
            fileref = open(reportfile, 'a')
            fileref.write('Error! This length in output xml is not a valid int length!' + name  + '\n')
            fileref.close()
        
        j += 1
    
    print 'output list:'
    print outputlist
    print    
    print 'outputdict:'
    print outputdict
    print   
    outlist = outputdict.keys()
    print'outlist:'
    print outlist
    print   
    global outputset
    outputset = set(outlist)
    print'outputset:'
    print outputset
    print   
    print 'output index:'
    print output_index
    print 'Total rows in output xml:' + str(j)

def splitbylen(a, c):
    '''
    #b = [a[0:2], a[2:6], a[6:24], a[24:38], a[38:52], a[52:54]]
    a ='There is Something in the river and also in the water need to be split                             '
    c = [2,4,18,14,14,2]    
    '''
    b = []
    i = 0
    for x in c:
        b.append(a[i:i+x])
        i += x
    return b
    

def check_output_data(outputfile, report):
    print '====Begin check Output data=========='
    outlistoflist = []
    global reportfile
    reportfile = report
    fileref = open(reportfile, 'a')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Output XML and Data Fields Comparison Report:' + '\n')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Following Output Fields Mismatch, rows and columns counted from 0,0: ' + '\n')
               
    fileref.write("output data file mismatch with the output configure xml at \n")
    fileref.write("[Row No., Column No., Output XML length, Real length in output data file, Column name]" + '\n')
    fileref.write('-------------------------------------------------' + '\n'*2)
    
    outputlist[0].values()[0]

    f = open(outputfile,'r')
    #print'xml output index:'
    #print output_index
    n = 0    
    for n , line in enumerate(f):
        print'---- iterate rows of output data ----'
        #print 'row: ', n
        line = line.rstrip('\n')       
        #print'len of output file line:'
        print 'row: ' + str(n)+' has ' + str(len(line)) +' length in output file'
        #print len(line)
        #print line
                
        list1 = splitbylen(line,output_index)
        print ' now list1 is .....'
        print list1
        outlistoflist.append(list1)
        
        if len(list1)!= len(output_index):
            print'Size mismatch between output data file  with the output configure xml!'
            fileref.write('Size Mismatch between output data file  with the output configure xml!\n')
        
        
        for i in range(len(list1)):
            #print 'out data length : ', len(list1[i])
            #print 'out xml  length : ', output_index[i] 
            print 'out data length : ' + str(len(list1[i])) + ' | out xml  length : ' + str(output_index[i]) 
            if len(list1[i]) != output_index[i]:
                print 'output data file mismatch with the output configure xml at row:', n , ' column:', i ,' column name:',outputlist[i].keys()[0]
                print 

                #print outputlist[i].keys()[0]
         
                
                fileref.write(' row:' + str(n) +', column:' +str(i)+ ' , '+str(output_index[i])\
                 + ' , ' + str(len(list1[i])) + ' , ' + outputlist[i].keys()[0] +'\n')    
            
            print 'Output value in data:',(list1[i])            
        print
        n  = n + 1        
    print
    print'Total output data row: ',  n  
           
    fileref.close() 
    f.close()
    return outlistoflist
    
def removequote(string,n,i):
    string = string.strip()
    #if string.startswith('"') and string.endswith('"'): 
        #string = string[1:-1]
    
    if string.startswith('"'):
        if string.endswith('"'):
            #print'has both quotes'
            string = string[1:-1]        
        else:
            print'Has Start quote but No end quote in row:' + str(n) + ' ,in col:' + str(i) + ' ,Value:' + string
            fileref = open(reportfile, 'a')
            fileref.write('Has start quote but No end quote in row:' + str(n) + ' in col:' + str(i) + 'Value:' + string + '\n')
            fileref.close()
    else:
        if string.endswith('"'):
            print'Has End quote but No start quote in row:' + str(n) + ' ,in col:' + str(i) + ' ,Value:' + string
            fileref = open(reportfile, 'a')
            fileref.write('Has end quote but No start quote in row:' + str(n) + ' in col:' + str(i) + 'Value:' + string + '\n')
            fileref.close() 
        else:
            #print'No quote at all'
            pass
        
    string = string.strip() #For field delimited file don't worry about spaces
    return string

def check_sftp_data(outputfile, report):
    print '====Begin check sftp file data=========='
    inlistoflist = []
    global reportfile
    reportfile = report
    fileref = open(reportfile, 'a')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Output XML and SFTP Data Fields Comparison Report:' + '\n')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Following SFTP Fields Mismatch, rows and columns counted from 0,0: ' + '\n')
               
    fileref.write("sftp data file mismatch with the output configure xml at \n")
    fileref.write("[Row No., Column No., Output XML length, Real length in sftp data file, Column name]" + '\n')
    fileref.write('-------------------------------------------------' + '\n'*2)
    
    f = open(outputfile,'r')
    #print'xml output index:'
    #print output_index
    n = 0    
    for n , line in enumerate(f):
        print'---- iterate rows of sftp file data ----'
        #print 'row: ', n
        line = line.rstrip('\n')       
        #print'len of output file line:'
        print 'row: ' + str(n)+' has ' + str(len(line)) +' length in output file'
        #print len(line)
        #print line
                
        list1 = splitbylen(line,output_index)
        print ' now list1 is .....'
        print list1
        inlistoflist.append(list1)
        
        if len(list1)!= len(output_index):
            print'Size mismatch between output data file  with the output configure xml!'
            fileref.write('Size Mismatch between output data file  with the output configure xml!\n')
        
        
        for i in range(len(list1)):
            #print 'out data length : ', len(list1[i])
            #print 'out xml  length : ', output_index[i] 
            print 'sftp data length : ' + str(len(list1[i])) + ' | out xml  length : ' + str(output_index[i]) 
            if len(list1[i]) != output_index[i]:
                print 'sftp data file mismatch with the output configure xml at row:', n , ' column:', i ,' column name:',outputlist[i].keys()[0]
                print 

                #print outputlist[i].keys()[0]
         
                
                fileref.write(' row:' + str(n) +', column:' +str(i)+ ' , '+str(output_index[i])\
                 + ' , ' + str(len(list1[i])) + ' , ' + outputlist[i].keys()[0] +'\n')    
            
            print 'sftp file value in data:',(list1[i])            
        print
        n  = n + 1        
    print
    print'Total sftp file data row: ',  n   
           
    fileref.close() 
    f.close()
    return inlistoflist


def Compare_input_ouput_data(listi, listo):
    print'Begin comparing input and output data...'
    global reportfile
    t = 0 # total dismatch found
    fileref = open(reportfile, 'a')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('SFTP and Output Data to Data Fields Comparison Report:' + '\n')
    fileref.write('------------------------' + '\n'*2)
    #fileref.write('Following Input and Output Fields Mismatch, rows and columns counted from 0,0: ' + '\n')
    
    r1 =  len(listi)           
    r2 =  len(listo)
    print'row of input data:'
    print r1 
    print'row of output data:'
    print r2    
    
    if r1 != r2:
        print'Mismatch found, input : output data files rows number are not equal ' + str(r1)+' :  ' + str(r2)        
        fileref.write('Mismatch found, input : output data files rows number are not equal ' + str(r1)+' :  ' + str(r2) + '\n')
    
       
    else:
        fileref.write("Input data file mismatch with the output data file at \n")
        fileref.write("[Row No., Column Name, Input Column No., Output Column No., Input data value, Output data value]" + '\n')
        fileref.write('-------------------------------------------------' + '\n'*2)
        for i in range(r1):# iterate each row of input and output data
            print('list of list row: ' + str(i))
            dc = 0
            for e in outputdict:
                
                print 'Out xml', outputdict[e]            ,
                valout = listo[i][outputdict[e][1]] #output is fixed length
                if fixlen == 1:
                    valin = listi[i][outputdict[e][1]]
                else: # field delimited file, fixlen != 1   
                    valin = listi[i][inputdict[e]]
                    valin = valin.strip()                                                 
                    valout = valout.strip() # field delimited file do not worry spaces  
                co = outputdict[e][1]
                ci = outputdict[e][1]
               # print 'in data col:' + str(ci)        ,
                print 'data col:' + str(co)
                print 'in data:' + valin #+'END'
                print 'ot data:' +valout #+'END'
                
                print 'input sftp data value: ' + valin + ' output data value: ' + valout
                if valin != valout:
                    t = t+1
                    print'Dismatch found! Input sftp data value Not match output data value!' 
                   # fileref.write(' row:' + str(i) + ', input column No:' +str(ci)+ ', input column No:' + str(co)\
                   # + 'input data: ' + valin + ' output data: ' +valout + '\n')
                    fileref.write(str(i)+','+e+','+str(ci)+','+str(co)+','+valin+','+valout+'\n')
                #pass        
                print
        dc = dc +1
        print 'total columns:',dc
    
        
        fileref.write('-------------------------------------------------' + '\n'*2)         
        fileref.write('Total mismatch found: ' + str(t) +'\n')
    fileref.close() 
    print'row of sftp data:'
    print r1 
    print'row of output data:'
    print r2
    print'Comparision completed!==========================\n'

def sftp_compare_data(file1,file2,report,outputxml):
    global reportfile
    reportfile = report
    check_output_xml(outputxml, report)
    listinput = check_sftp_data(file1, report) 
    listoutput = check_output_data(file2, report)
  
    Compare_input_ouput_data(listinput, listoutput)  

	
def psvify(value_list, clip_columns=[]):
    '''Converts a list into psv values
    >>psvify([('a','1'),('b','2')])
    '''
    psvfied = []
    for values in value_list:
        joined = ','.join(str(i) for i in values)
        #joined = '|'.join(str(j) for i,j in enumerate(values) and j not in clip_columns)
        ###Blanks out the None values from a line. 
        #joined.replace("None","")
        psvfied.append(joined)
    return psvfied
