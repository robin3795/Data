# Joseph(Qiao)Pu 
# 14 Sep. 2016
'''
Test Senario Summary 
If there is no input file on a particular date, then the output GFF should be zero KB
Description :
This has two situations: 1. NO input file at all.  2. Input file is zero KB.  It leading the output GFF is zero KB.
As reverse, if the output GFF is zero KB, the input can be NO input file, or zero KB file.

ZeroKbFilecheck1
steps: 1. Get file from SFTP server. 2. Get file from Output folder
3.Check if output GFF is zero KB?  If it is, go to step4
4.Verify if input folder has no file, or has 0 KB file.

Reverse testing: ZeroKbFilecheck2
steps: 1. Get file from SFTP server. 2. Get file from Input folder
3. Check if input  input folder has no file, or has 0 KB file, if it is, go to step4
4. Verify if output GFF is zero KB.
'''

import os.path
import sys

def fileCountIn(dir):
    return sum([len(files) for root,dirs,files in os.walk(dir)])

def ZeroKbFilecheck1(indir,outdir,outfile,reportfile):
    fileref = open(reportfile, 'a')
    fileref.write('\n')
    fileref.write('--------------------------------------------------------------------------------------------------' + '\n'*2)
    print ' input dir: ', indir, '\n output dir: ', outdir, '\n output file: ', outfile
    s = os.path.getsize(outfile)
    print 'output file size:', s
    if s == 0:
        print'found zero kb output file, will check input'
        inputFileNum = fileCountIn(indir)
        print 'Have input file number:', inputFileNum
        if inputFileNum == 0 :
            print'No file found at input dir'
        else:
            print'Have at least one input file, will check size'
            for root,dirs,files in os.walk(indir):
                print files
                for f in files:
                    print f
                    file2 = os.path.join(indir, f)
                    print file2
                    s2 = os.path.getsize(file2)
                    print 'Input file :' , f, ' Size: ', s2
                    if s2 > 0:
                        print'Mismatch found! for Zero Kb output file: ' , outfile ,' found input file:', f, ' great than zero kb !'                        
                        fileref.write('\n Mismatch found! For Zero Kb output file: ' + outfile + ' , found input file: '+ file2 + ' great than zero kb ! \n')                                                            
    else:
        print'not a zero kb Output file'
    fileref.close()

def ZeroKbFilecheck2(indir,outdir,outfile,reportfile):
    flag = 0
    fileref = open(reportfile, 'a')
    fileref.write('\n')
    fileref.write('--------------------------------------------------------------------------------------------------' + '\n'*2)
    print ' input dir: ', indir, '\n output dir: ', outdir
    inputFileNum = fileCountIn(indir)
    print 'Have input file number:', inputFileNum
    if inputFileNum == 0 :
        print'No file found at input dir'
        flag = 0
    else:
        print'Have at least one input file, will check size'
        for root,dirs,files in os.walk(indir):
            print files
            for f in files:
                print f
                file2 = os.path.join(indir, f)
                print file2
                s2 = os.path.getsize(file2)
                print 'Input file :' , f, ' Size: ', s2
                if s2 > 0:
                    print' great than zero input file found'
                    flag = 1
                    
    if flag == 0: #None input file, or input file size is zero
        s = os.path.getsize(outfile)
        if s >0 :
            print'Mismatch found! for Zero Kb input file or None input file, found Output file:', outfile, ' great than zero kb !'                        
            fileref.write('\n Mismatch found! for Zero Kb input file or None input file, found Output file: ' + outfile + ' great than zero kb ! \n')        
        else:
            print 'None input file, output file is zero kb,  that is ok'
 
if __name__ == '__main__':
    #inputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\800\20160804104335_6_Clnt.DAT'
    outputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\800\20160805141829_6_Clnt.DAT' #zero kb
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\800\20160804104335_6_Clnt.DAT' # not zero kb
    inputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\800\Input'
    outputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\800'
    report = r'C:\work\Country_Name_Scan\Sprint5\Results\Check_ZeroKbFile_report12.txt'
    ZeroKbFilecheck1(inputdir,outputdir,outputfile1,report)
    ZeroKbFilecheck2(inputdir,outputdir,outputfile1,report)
        
    
   
    