update RUFH0F.ACCOUNTS set last_updated_timestamp = current_timestamp where account_source_unique_id='00522-5589740000002088'
update RUFH0F.WORKFLOW_WORKITEM set CREATION_TIMESTAMP = current_timestamp where ENTITY_KEY_NUM=7335
update RUFH0F.WORKFLOW_WORKITEM set CREATION_TIMESTAMP = current_timestamp where ENTITY_KEY_NUM=6620
update RUFH0F.WORKFLOW_WORKITEM set CREATION_TIMESTAMP = current_timestamp where ENTITY_KEY_NUM=6884
update RUFH0F.ASSOCIATED_INFORMATION set last_updated_timestamp = current_timestamp where assoc_info_id =10015887
update RUFH0F.ASSOCIATED_NAMES set last_updated_timestamp = current_timestamp where assoc_name_id=2478
update RUFH0F.ASSOC_INFO_ADDRESSES set last_updated_timestamp = current_timestamp where assoc_info_id=6693
update RUFH0F.ASSOC_INFO_CHARACTERISTICS set last_updated_timestamp = current_timestamp where CHARACTERISTICS_ID=1000
update RUFH0F.ASSOC_INFO_EMPLOYER_DETAILS set last_updated_timestamp = current_timestamp where Employer_details_id = 7058
update RUFH0F.ASSOC_INFO_IDENTIFICATION set last_updated_timestamp = current_timestamp where identification_id =1202
update RUFH0F.ASSOC_INFO_IDENTIFICATION_BK set last_updated_timestamp = current_timestamp where identification_id=70759
update RUFH0F.ASSOC_INFO_PHONES set last_updated_timestamp = current_timestamp where phone_id = 10012266
update RUFH0F.workflow_action_log set logtimestamp = current_timestamp where entity_key_num = 10011488
update RUFH0F.workflow_action_log set logtimestamp = current_timestamp where entity_key_num = 1849
update RUFH0F.CUSTOMERS set last_updated_timestamp = current_timestamp where customer_id='00002-400011486'
update RUFH0F.CUSTOMER_ADDRESSES set last_updated_timestamp = current_timestamp where customer_id='00004-3421884' and address_id=1
update RUFH0F.CUSTOMER_ASSOC_INFO set last_updated_timestamp = current_timestamp where assoc_id='NC001-20140418040447406019001'
update RUFH0F.CUSTOMER_PHONES set last_updated_timestamp = current_timestamp where phone_id='NC002-2014041605194778249401001'
update RUFH0F.CUSTOMER_RISK_PROFILE set last_updated_timestamp = current_timestamp where id=1204
update RUFH0F.WORKFLOW_ACTION_LOG set LOGTIMESTAMP = current_timestamp where AUDIT_SEQUENCE = 19204 and ENTITY_KEY_NUM = 1849
update RUFH0F.WORKFLOW_ACTION_LOG set LOGTIMESTAMP = current_timestamp where WORKFLOW_WORKITEM_ID = 13749
update RUFH0F.DF_ACKNOWLEDGE set CREATED_TIMESTAMP = current_timestamp where BATCH_KEY=8000001
update RUFH0F.DF_ACKNOWLEDGE set CREATED_TIMESTAMP = current_timestamp where ACKNOWLEDGE_ID=1010
update RUFH0F.ROLES set last_updated_timestamp = current_timestamp where id=1053
update RUFH0F.TRANSACTIONS set LOCAL_TIMESTAMP = current_timestamp where txn_id='A00022014041506103204001001'
update RUFH0F.WORKFLOW_ACTIONS set last_updated_timestamp = current_timestamp where id=1020
update RUFH0F.WORKFLOW_ACTION_LOG set logtimestamp = current_timestamp where audit_sequence=3768
update RUFH0F.WORKFLOW_ACTION_REASONS set last_updated_timestamp = current_timestamp where id = 1203
update RUFH0F.WORKFLOW_STATUSES set last_updated_timestamp = current_timestamp where id =1064
update RUFH0F.WORKFLOW_WORKITEM set LATEST_ACTION_TIMESTAMP = current_timestamp where id =25043
update RUFH0F.WORKFLOW_WORKITEM_LINK set FROM_TIMESTAMP = current_timestamp where id =10022774
update RUFH0F.WORKFLOW_DOCUMENT set DOCUMENT_TIMESTAMP = current_timestamp where id=1873
update RUFH0F.WORKFLOW_NOTE set CREATED_TIMESTAMP = current_timestamp where id =1149
update RUFH0F.ALERT_DETAILS_AML set EXT_CREATION_TIMESTAMP = current_timestamp where alert_key=6883
update RUFH0F.DOMAIN_REPORTING_REASONS set LAST_UPDATED_TIMESTAMP = current_timestamp where code ='FRD_B_ERROR_OTHER'