#!c:/Python27/python.exe
# Created Date: June 29 2016

import xml.etree.ElementTree as etree
import re

def get_connection_info(xmlfile):
    '''
    (str)->dict
    Parse xml file and return dictionary of connection information for GCM
    >>> get_connection_info('C:\\path\\to\\filename.xml')
    {'User': 'DDWV01', 'Url': 'server:8080:DB'}
    '''
    con_dic = {}
    t = etree.parse(xmlfile)
    r = t.getroot()
    alist = r.findall('property')
    for i, element in enumerate(alist):
        x = alist[i].find('name').text
        y = alist[i].find('value').text
        if ('Url' in x):
            con_dic['Url'] = y
        elif ('User' in x):
            con_dic['User'] = y
        elif ('Password' in x):
            con_dic['Password'] = y
        elif ('schema' in x):
            con_dic['schema'] = y
        elif ('Port' in x):
            con_dic['Port'] = y
        elif ('Database' in x):
            con_dic['Database'] = y
        elif('Driver' in x):
            con_dic['Driver'] = y
    if ('@' in con_dic['Url']):
        con_dic['Url'] = (re.sub(r"\:(?=[^:]*$)", "/", con_dic['Url'])).split("@")[1]
    return con_dic

#if __name__=="__main__":
#    mydict = get_connection_info('..\Data\connectionStringGCM.xml')
#    print(mydict)