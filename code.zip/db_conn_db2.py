# Please see the comment below before you run it
#'Driver=${DB_Driver};Database=${DB_DatabaseName};Hostname=${DB_Host};Port=${Portno};Protocol=TCPIP;Uid=${DB_Username};Pwd=${DB_Password};
import pyodbc


def db_conn_DB2(User, Password, SQLQuery):
    '''
    (str, str, str)-> list
    PREREQUISITE: pyodbc
    USE: This function connect to  database, run SQL Queries and return query record
    '''        
    
    connstr= "DRIVER={IBM DB2 ODBC Driver};Hostname=service.app.com;DATABASE=DBName;Port=50000;PROTOCOL=TCPIP;UID=" + User + ";PWD=" + Password
            
    print ("connstr is: ",connstr)
    conn = pyodbc.connect(connstr)
    vcursor = conn.cursor()

    rs = vcursor.execute(SQLQuery)
    row = vcursor.fetchall()
    return row


if __name__ == '__main__':
    # Replace xxxx with your username and yyyy with your password
    
    query = "SELECT CLNT_NO, SUBSTR(field,9,5) AS TR_NO FROM tableName WHERE sourceId = 111 AND SUBSTR(field,9,5) in ('00002') FOR FETCH ONLY WITH UR"
    myrecord = db_conn_DB2("xxxx","yyyy",query)

    for i in range(len(myrecord)):
        print(myrecord[i])
