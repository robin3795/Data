select field1,....,filedn from schema.table1 where filedi='xxxxx' and VERTICA_LOADING_DATE BETWEEN SYSDATE-1 AND SYSDATE;
..........
select field1,....,filedn from schema.tablen where filedi='xxxxx' and VERTICA_LOADING_DATE BETWEEN SYSDATE-1 AND SYSDATE;

