#!c:/Python27/python.exe
# Robin Li Aug 12 2016

import re
import os
from lxml import etree

# The file path is /dev/AppCode/data/dm/SourceID/year/month/day/filename
# The filename format is SourceID_Name_yyyymmddhhmmss.extension
# SourceID is alphanumeric
# yyyymmdd is 8 digit, and hhmmss is 6 digit
# The common data file extension is : .dat, .xls, and .csv

def get_SourceID(filename):
    '''
    >>> get_fileID("618_20160425-132128_MOCK_LVS.xls")
    '618'
    '''
    id = re.match('^\w+?_', filename)
    if id != None:
        return id.group(0).replace("_", "")

def get_SourceID_from_path(filepath):
    '''
    >>>get_fileID_from_path('/user/RL/dev/up20/data/2016/02/28/618_MissingClient_20160228094011.xls')
    '618'
    '''
    id = re.findall(r'/\w+?_', filepath)
    if id != None:
        id = id[0].replace("_", "")
        id = id.replace(r"/", "")
    return id

def get_stampdate(filename):
    '''
    >>> get_stampdate("LV01_20160425-132128_MOCK_LVS.xls")
    '20160425'
    >>> get_stampdate("618_20160425-132128_MOCK_LVS.xls")
    '20160425'
    >>> get_stampdate('110phone_2012_05_13.csv.1464567631543.tmp')
    '20120513'
    '''
    # stampdate = re.search('_\d+', filename)
    # regular expression to match dates in format: yyyy-mm-dd, yyyy/mm/dd, yyyy_mm_dd, _yyyymmdd
    date_reg_exp = re.compile('\d{4}[-/_]\d{2}[-/_]\d{2}|_[0-9]{8}')

    stampdate = date_reg_exp.search(filename)
    if stampdate != None:
        stampdate = stampdate.group(0).replace("_", "")
        stampdate = stampdate.replace("/", "")
        stampdate = stampdate.replace("-", "")
        return stampdate

# Previous name of filter_filelist_by_date function was get_filename_between_timestamp
def filter_filelist_by_date(filelist, startdate="", enddate=""):
    '''
    (list, str, str)->list
    Return a list of file names within a range of timestamp. File names without timestamp are ignored.
    startdate and enddate format are 'yyyymmdd' like the timestamp
    >>> alist = ['601_20090510115603_6_Clnt.dat', '804_20160513012345_6_Clnt.dat', 'LV01_20160508-230558_LVS_MFDClient.CSV', 'LV01_230558_MOCK_LVS.xls', 'LV073_MFDClient_Weekly_20160510093822.csv', 'LV077_MissingRBCDIClient_20130510094011.xls']
    >>> filter_filelist_by_date(alist, '20150131', '20160425')
    []
    >>> filter_filelist_by_date(alist, '20160101', '')
    ['804_20160513012345_6_Clnt.dat',
     'LV01_20160508-230558_LVS_MFDClient.CSV',
     'LV073_MFDClient_Weekly_20160510093822.csv']

    '''
    selected = []

    for f in filelist:
        if get_stampdate(f) == None:
            filelist.remove(f)

    if startdate != "" and enddate != "":
        for name in filelist:
            stampdate = get_stampdate(name)
            if stampdate >= startdate and stampdate <= enddate:
                selected.append(name)

    elif startdate != "" and enddate == "":
        for name in filelist:
            stampdate = get_stampdate(name)
            if stampdate >= startdate:
                selected.append(name)

    elif startdate == "" and enddate != "":
        for name in filelist:
            stampdate = get_stampdate(name)
            if stampdate <= enddate:
                selected.append(name)

    elif startdate == "" and enddate == "":
        selected = filelist

    else:
        pass

    return selected


def filter_filelist_by_ext(filelist, ext):
    '''
    (list, str)->list
    >>> filter_filelist_by_ext(['aayan.exe', 'arishi.pdf', 'nawshin.doc', 'mohin.tmp'], '.tmp')
    ['aayan.exe', 'arishi.pdf', 'nawshin.doc']
    >>> filter_filelist_by_ext(['home/m/aayan.exe', 'home/f/arishi.pdf', 'home/f/nawshin.doc'], '.exe')
    ['home/f/arishi.pdf', 'home/f/nawshin.doc']
    '''
    finallist = []
    for itm in filelist:
        if itm[itm.rfind('.'):] != ext:
            finallist.append(itm)
    return finallist


def get_file_extension(filename):
    '''
    (str)->str
    return file extension
    >>> get_fileex('wxpython.tar.gz')
    '.gz'
    >>> get_fileex('C:\dqqa\branches\Current\Scripts\wxpython.tar.gz')
    '.gz'
    >>> get_fileex('/dev/up20/data/this_is.a-folder/edw/001pers/2012/05/23/001pers_2012_05_23.csv.1464748154722.tmp')
    '.tmp'
    '''
    return filename[filename.rfind('.'):]

def get_common_path(filepath, subfolder):
    '''
    (str)->str
    return common path which is the path before the assigned subfolder
    >>> get_common_path('/dev/AppCode/data/input/year/month/day/filename.dat')
    '/dev/AppCode/data'
    '''
    common_path = filepath.split(subfolder)[0]
    return common_path

def read_file_line(File_Line):
    '''
    (str)->alist
    return a list of a string separated by '|'
    >>> read_file_line('a|b')
    '['a','b']'
    '''
    file_line_list = File_Line.split("|")
    for i in range (len(file_line_list)):
        file_line_list[i]=file_line_list[i].strip()
    return file_line_list

def get_next_subfolder_name(pathfile,subfolder):
    '''
    (str)->str
    return the next subfoler name in a path
    >>> get_next_subfolder_name('/a/b/c/d/e/file.ext','b'
    'c'
    '''
    pathfile_list = pathfile.split("/")
    for i in range (len(pathfile_list)):
        if pathfile_list[i] == subfolder:
            return pathfile_list[i+1]

def get_file_name(pathfile):
    '''
    (str)->str
    return the file name in a path
    >>> get_next_subfolder_name('/a/b/c/d/e/file.ext')
    'file.ext'
    '''
    return os.path.basename(pathfile)

def get_date_path_from_path(pathfile,subfolder='dm'):
    '''
    (str)->str
    return common path which is the path before the assigned subfolder
    >>> get_common_path('/dev/AppCode/data/dm/SourceID/year/month/day/filename.dat')
    '[year\\month\\day']'
    '''
    pathfile_list = pathfile.split("/")
    date_list = []
    for i in range (len(pathfile_list)):
        if pathfile_list[i] == subfolder:
            date_list.extend((pathfile_list[i+2],pathfile_list[i+3],pathfile_list[i+4]))
    date_path = date_list[0]+"\\"+date_list[1]+"\\"+date_list[2]
    return date_path

def get_date_path_from_date(load_date):
    '''
    (str)->str
    return daten path from assigned date
    >>> get_date_path_from_date('year_month_day')
    '[year\\month\\day']'
    '''
    date_list = load_date.split("_")
    date_path = date_list[0]+"\\"+date_list[1]+"\\"+date_list[2]
    return date_path

def get_date_path_from_date_hdfs(load_date):
    '''
    (str)->str
    return daten path from assigned date
    >>> get_date_path_from_date('year_month_day')
    '[year/month/day']'
    '''
    date_list = load_date.split("_")
    date_path = date_list[0]+"/"+date_list[1]+"/"+date_list[2]
    return date_path

def get_date_str_from_path(pathfile,subfolder='dm'):
    '''
    (str)->str
    return common path which is the path before the assigned subfolder
    >>> get_common_path('/dev/AppCode/data/dm/SourceID/year/month/day/filename.dat')
    'year_month_day'
    '''
    pathfile_list = pathfile.split("/")
    date_list = []
    for i in range (len(pathfile_list)):
        if pathfile_list[i] == subfolder:
            date_list.extend((pathfile_list[i+2],pathfile_list[i+3],pathfile_list[i+4]))
    date_str = date_list[0]+"_"+date_list[1]+"_"+date_list[2]
    return date_str
	
def get_file_name_from_path(Path_File):
    filename = os.path.basename(Path_File)
    return filename
   
def get_tablename_from_query(query):
    table_name = re.search('\w+[.](\w+)', query, re.IGNORECASE)
    return table_name.group(1)

def parse_edw_sql_xml(xmlfile, table):
    '''
    (str,str)->dict
    Parse xml file and return sql statement dictionary of each table only for Verita reporting project.
    NOTE: This function depends on the structure of following XML:
    <property>
        <name>dt.operator.edwInput.jdbcSql(table)</name>
        <value>
        <![CDATA[LOCKING ROW FOR ACCESS SELECT column1, coumn2 FROM table]]>
        </value>
    </property
    >>>parse_edw_sql_xml(xmlfile, table)
    'SELECT column1, coumn2 FROM table'
    '''    
    #SourceDict = {}
    tree = etree.parse(xmlfile)
    root = tree.getroot()
    table_string ='(' + table + ')'
    alist = root.findall('property')
    sql=''
    for i in range(len(alist)):
        x = alist[i].find('name').text
        if table_string in x:
            y = alist[i].find('value').text
            select_index = y.index('SELECT')
            sql = y[select_index:].strip()
    return sql

def parse_mapped_value(xmlfile, input_value):
    '''
    (str,str)->dict
    Parse xml file and return sql statement dictionary of each table only for Verita reporting project.
    NOTE: This function depends on the structure of following XML:
    <property>
        <name>Account_Status.SNAP_DT</name>
        <value>ACM_AR_STS_DLY.SNAP_DT</value>
    </property>
     >>>parse_mapping_coulumn_with_xml(xmlfile, tableA.column1)
    'tableB.column_1'
    '''
    tree = etree.parse(xmlfile)
    root = tree.getroot()
    mapped_value=''
    alist = root.findall('property')
    for i in range(len(alist)):
        x = alist[i].find('name').text
        y = alist[i].find('value').text
        if input_value.upper() in x.upper():
            mapped_value = y
        elif input_value.upper() in y.upper():
            mapped_value = x
    return mapped_value

