#!c:/Python27/python.exe
# Created Date: July 08 2016

import re, difflib

def compare_files(source, target, counter=2):
    '''Compares two PSV files line by line for the given count
    >>>compare_files("\path\to\source.psv", "\path\to\dest.psv", 20)
    '''
    result_list = []
    source_file = open(source, "r")
    target_file = open(target, "r")
    for i in range(int(counter)):
        x = source_file.readline()
        y = target_file.readline()
        if(x == y):
            result_list.append(str(i+1)+", Passed\n")
        else:
            to_append = str(i+1)+", "+column_check(x.split("|"),y.split("|"))+"\n"
            result_list.append(to_append)
    return result_list

def compare_search(source, target, counter=2):
    '''Compares two PSV files by searching for each line from source file in the target file
    Ideally
    >>>compare_search("\path\to\source.psv", "\path\to\dest.psv", 20)
    '''
    result_list = []
    source_file = open(source, "r")
    target_file = open(target, "r")
    y = target_file.readlines()
    counter=min(counter, len(y))
    for i in range(int(counter)):
        x = source_file.readline()
        x = clean_line_trailing_newline(clean_line_trailing_space(clean_line_ms_padding(clean_line_dec_padding(x))))
        if(x in y):
            result_list.append(str(i+1)+", Passed\n")
        elif(clean_line_time_truncation(x) in y):
            result_list.append(str(i+1)+", Passed\n")
        else:
            to_append = str(i+1)+", Failed, record not found, "+x+"\n"
            result_list.append(to_append)
    return result_list
    
def compare_unordered(source, target, counter=2):
    '''Compares two PSV files line by line where line items may be out of order
    >>>compare_unordered("\path\to\source.psv", "\path\to\dest.psv", 20)
    '''
    result_list = []
    source_file = open(source, "r")
    target_file = open(target, "r")
    for i in range(int(counter)):
        x = source_file.readline()
        y = target_file.readline()
        x = clean_line_trailing_newline(clean_line_trailing_space(clean_line_ms_padding(clean_line_dec_padding(x))))
        if(set(x.split("|")) == set(y.split("|"))):
            result_list.append(str(i+1)+", Passed\n")
        else:
            x=clean_line_time_truncation(x)
            if(set(x.split("|")) == set(y.split("|"))):
                result_list.append(str(i+1)+", Passed\n")
            else:
                to_append = str(i+1)+", Failed, Values do not map\n"
                result_list.append(to_append)
    return result_list

def psvify(value_list, clip_columns=0):
    '''Converts a list into psv values
    >>psvify([('a','1'),('b','2')])
    '''
    psvfied = []
    clip_columns=int(clip_columns)
    for values in value_list:
        if(clip_columns>0):
            values = values[:-clip_columns]
        joined = '|'.join(str(i) for i in values)
        #Future: joined = '|'.join(str(j) for i,j in enumerate(values) and j not in clip_columns)
        joined = clean_record(joined)
        psvfied.append(joined)
    return psvfied

def column_check(list1, list2):
    '''Compares two rows field by field
    >>> print column_check(['this', 'is', 'a', 'test', 'too'], ['this', 'is.000000', 'a.0', 'test 00:11:22.000000', 'two'])
    '''
    if(len(list1)==len(list2)):
        result_list = []
        co_list = zip(list1,list2)
        for i,co_field in enumerate(co_list):
            if(co_field[0]==co_field[1]):
                pass
            elif(co_field[0]==clean_ms_padding(co_field[1])):
                result_list.append("Passed, "+str(i)+", MicroSecond padding")
            elif(co_field[0]==clean_dec_padding(co_field[1])):
                result_list.append("Passed, "+str(i)+", Decimal padding")
            elif(co_field[0]==clean_time_truncation(co_field[1])):
                # also uses the clean_ms_padding function
                result_list.append("Passed, "+str(i)+", TimeStamp truncated")
            elif(co_field[0]==clean_trailing_space(co_field[1])):
                result_list.append("Passed, "+str(i)+", Trailing space truncated")
            elif(co_field[0]==clean_leading_space(co_field[1])):
                result_list.append("Passed, "+str(i)+", Leading space truncated")
            elif(co_field[0]==clean_trailing_newline(co_field[1])):
                result_list.append("Passed, "+str(i)+", Trailing newline truncated")
            else:
                result_list.append("Failed, "+str(i)+", "+co_field[0]+", <>, "+co_field[1])
    else:
        return "Failed, row length mismatch"
    return (", ").join(result_list)

def clean_record(record):
    '''Blanks out the None values from a line. 
    >>>clean_record("this|is|a|None|test")
    '''
    #return re.sub('(?<=[\n\\|])(None)(?=[\n\\|])', '', record)
    return record.replace("None", "")

def clean_ms_padding(record):
    '''Takes out microsecond digits in single field'''
    return re.sub('[.]\d{6}','',record)

def clean_dec_padding(record):
    '''Takes out decimal digits in single field'''
    return re.sub('[.]\d{1}','',record)

def clean_time_truncation(record):
    '''Takes out entire time value in single field'''
    record = clean_ms_padding(record)
    return re.sub('[ ]\d{2}[:]\d{2}[:]\d{2}','',record)

def clean_trailing_space(record):
    '''Takes out trailing space in single field'''
    return record.rstrip()

def clean_leading_space(record):
    '''Takes out leading space in single field'''
    return record.lstrip()

def clean_trailing_newline(record):
    '''Takes out trailing newline in single field'''
    return record.rstrip("\n")

def clean_line_ms_padding(record):
    '''Takes out microsecond digits in line'''
    return re.sub('[.]\d{6}(?=[||\n])','',record)

def clean_line_dec_padding(record):
    '''Takes out decimal digits in line'''
    return re.sub('[.]\d{1}(?=[||\n])','',record)

def clean_line_time_truncation(record):
    '''Takes out entire time values in line'''
    record = clean_ms_padding(record)
    return re.sub('[ ]\d{2}[:]\d{2}[:]\d{2}(?=[||\n])','',record)

def clean_line_trailing_space(record):
    '''Takes out trailing spaces in line'''
    return re.sub('[ ](?=[||\n])','',record)

def clean_line_trailing_newline(record):
    '''Takes out trailing newlines in line'''
    return re.sub('[\n](?=[||\n])','',record)

def compare_strings(s1,s2):
    ''' Compares two strings'''
    return str(s1)==str(s2)

def compare_files_with_difflib(source,target):
    '''Compares two CSV files line by line for the given count
    >>>compare_files("\path\to\source.csv", "\path\to\dest.csv")
    '''
    source_file = open(source, "r")
    target_file = open(target, "r")
    x = source_file.readlines()
    y = target_file.readlines()
    diff= difflib.unified_diff(x,y)
    results = []
    for i in diff:
        results.append(i)
    return results