#!c:/Python27/python.exe

import string

def check_gff_mandatory_fields(inputfile):
    '''
    This file is to check if mandatory fields data in gff is empty, and check result in outpuf file.
    >>> check_gff_mandatory_fields("source_yearmonthday.gff")
    'source_yearmonthday_checked.gff'
    '''
    mandatory_fields = ['field1','field2','field3','field4','field5','field6','field7']
    start_index_list = [0,3,23,28,49,371,1858]
    field_length_list = [3,20,5,1,255,1,1]
    outputfilename=inputfile[::-1].replace('.','.dekcehc_',1)[::-1]
    reportfile = open(outputfilename,'w')
    failed_number = 0
    with open(inputfile) as infile:
        line_num = 1
        for line in infile:
            # data length check
            if(len(line) != 2360):
                error_message = 'The length of the line '+str(line_num) + ' is '+ str(len(line))+' and mismatch !!!\n'
                print error_message
                reportfile.write(error_message)
            # Mandatory fields check
            empty_fields = []
            for i in range(len(mandatory_fields)):
                start_index = start_index_list[i]
                end_index =start_index + field_length_list[i]
                field_value= line[start_index:end_index]
                if (field_value.strip() == ''):
                    field_name = mandatory_fields[i]
                    empty_fields.append(field_name)
            if len(empty_fields) >0 :    
                failed_number = failed_number+1
                if failed_number < 100:
                    error_message = 'In line '+str(line_num) +', empty fields:'+str(empty_fields) +'\n'
                    reportfile.write(error_message)
                    if failed_number < 10:
                        print error_message
            line_num = line_num+1
        if failed_number >0:
            total_info = str(failed_number)+' lines have empty mandatory fields'
        else:
            total_info = 'all pass, no line has empty mandatory fields'
        error_message ='Total '+str(line_num-1) +' lines, and '+total_info+'.\n'
        print error_message
        reportfile.write(error_message)
    reportfile.close()
    infile.close()
    print 'Done'

#check_gff_mandatory_fields("C:\projects\XXXXXX\XX_working\Data\Actual\810\810_output.dat")
#check_gff_mandatory_fields("C:\\projects\\XXXXXX\\XX_working\\Data\\Actual\\804\\20161021\\20161021104518_6_Clnt.DAT")
#check_gff_mandatory_fields("C:\\projects\\XXXXXX\\XX_working\\Data\\Actual\\810\\20161025\\20161025100459_6_Clnt.DAT")
check_gff_mandatory_fields("abc.txt")


