#!c:/Python27/python.exe

import xml.etree.ElementTree as ET
import sys
import re
import paramiko
import os
import os.path
import time
import csv

def parse_property_xml(xmlfile):
    tree = ET.parse(xmlfile)
    root = tree.getroot() 
    config_list = []
    sources_list = []
    single_source_list = []
    sourceid = ''
    for property in root.findall('property'):
        name = property.find('name').text
        value = property.find('value').text
        matchObj = re.search('\([^\(]+\)$' , name)
        if matchObj:
            if sourceid !=  matchObj.group():# new sourceid or blank                
                if sourceid != '' : 
                    sources_list.append(single_source_list) #new source id              
                sourceid = matchObj.group()
                single_source_list = []  #initial new list for new source
                single_source_list.append(sourceid)
                single_source_list.append(value)
            else:
                single_source_list.append(value)                
        else:
                config_list.append(value)
                pass
    config_list.append(sources_list)
    return config_list


'''
method to get the latest file from a remote sftp server path, transfer to the local given path
'''
def SFTPGetFiles(serverHost,serverPort,userName,keyFile,remotepath,localpath):
    ssh = paramiko.SSHClient()

    # automatically add keys without requiring human intervention
    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    
    serverPort=int(serverPort)

    #ssh.connect(sftpURL, username=sftpUser, password=sftpPass)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)

    if (len(files)>1):
        files.sort()
    item = files[-1]
    sftp_name="sftp_"+item
    localfile =  os.path.join (localpath,sftp_name)
    remotefile = remotepath+'/'+item
    ftp.get(remotefile,localfile)              

    ftp.close()
    ssh.close()
    return sftp_name

def SFTPGetAllFiles(serverHost,serverPort,userName,keyFile,remotepath,localpath):
    ssh = paramiko.SSHClient()

    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    
    serverPort=int(serverPort)

    #ssh.connect(sftpURL, username=sftpUser, password=sftpPass)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)

    for f in files:
        localfile =  os.path.join (localpath,f)
        remotefile = remotepath+'/'+f
        ftp.get(remotefile,localfile)
                
    ftp.close()
    ssh.close()


'''
method to remove one specified file in the remote sftp server
'''

def SFTPCleanFile(serverHost,serverPort,userName,keyFile,remotepath,file):
    ssh = paramiko.SSHClient()

    # automatically add keys without requiring human intervention
    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    
    serverPort=int(serverPort)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)
    #print files
    ftp.remove(file)

 
    ftp.close()
    ssh.close()

'''
method to remove all files in the given remotepath
'''
def SFTPCleanAllFile(serverHost,serverPort,userName,keyFile,remotepath):
    ssh = paramiko.SSHClient()

    # automatically add keys without requiring human intervention
    ssh.set_missing_host_key_policy( paramiko.AutoAddPolicy() )
    
    serverPort=int(serverPort)
    ssh.connect(serverHost, serverPort,username=userName, key_filename=keyFile )

    ftp = ssh.open_sftp()
    files = ftp.listdir(remotepath)
    #print files    

    for f in files:   
        remotefile = remotepath+'/'+f
        print remotefile
        ftp.remove(remotefile)
        #ftp.get(remotefile,localfile)

    ftp.close()
    ssh.close()


def check_sftp_data(outputfile, reportfile):
    print '====Begin check sftp file data=========='
    inlistoflist = []
    fileref = open(reportfile, 'a')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Output XML and SFTP Data Fields Comparison Report:' + '\n')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Following SFTP Fields Mismatch, rows and columns counted from 0,0: ' + '\n')
               
    fileref.write("sftp data file mismatch with the output configure xml at \n")
    fileref.write("[Row No., Column No., Output XML length, Real length in sftp data file, Column name]" + '\n')
    fileref.write('-------------------------------------------------' + '\n'*2)
    
    f = open(outputfile,'r')
    #print'xml output index:'
    #print output_index
    n = 0    
    for n , line in enumerate(f):
        print'---- iterate rows of sftp file data ----'
        #print 'row: ', n
        line = line.rstrip('\n')       
        #print'len of output file line:'
        print 'row: ' + str(n)+' has ' + str(len(line)) +' length in output file'
        #print len(line)
        #print line
                
        list1 = splitbylen(line,output_index)
        print ' now list1 is .....'
        print list1
        inlistoflist.append(list1)
        
        if len(list1)!= len(output_index):
            print'Size mismatch between output data file  with the output configure xml!'
            fileref.write('Size Mismatch between output data file  with the output configure xml!\n')
        
        
        for i in range(len(list1)):
            #print 'out data length : ', len(list1[i])
            #print 'out xml  length : ', output_index[i] 
            print 'sftp data length : ' + str(len(list1[i])) + ' | out xml  length : ' + str(output_index[i]) 
            if len(list1[i]) != output_index[i]:
                print 'sftp data file mismatch with the output configure xml at row:', n , ' column:', i ,' column name:',outputlist[i].keys()[0]
                print 

                #print outputlist[i].keys()[0]
         
                
                fileref.write(' row:' + str(n) +', column:' +str(i)+ ' , '+str(output_index[i])\
                 + ' , ' + str(len(list1[i])) + ' , ' + outputlist[i].keys()[0] +'\n')    
            
            print 'sftp file value in data:',(list1[i])            
        print
        n  = n + 1        
    print
    print'Total sftp file data row: ',  n   
           
    fileref.close() 
    f.close()
    return inlistoflist


def sftp_compare_data(file1,file2,report,outputxml):
    global reportfile
    reportfile = report
    check_output_xml(outputxml, report)
    listinput = check_sftp_data(file1, report) 
    listoutput = check_output_data(file2, report)
  
    Compare_input_ouput_data(listinput, listoutput)


def check_gff_mandatory_fields(inputfile):
    mandatory_fields = ['SYS_SRC_ID','CLNT_NO','DIV_ID','DEL_IND','CLNT_NM','CLNT_TYP','STS']
    start_index_list = [0,3,23,28,49,371,1858]
    field_length_list = [3,20,5,1,255,1,1]
    outputfilename=inputfile.replace('.','_check.',-1)
    reportfile = open(outputfilename,'w')
    failed_number = 0
    with open(inputfile) as infile:
        line_num = 1
        for line in infile:
            # data length check
            if(len(line) != 2360):
                error_message = 'The length of the line '+str(line_num) + ' is '+ str(len(line))+' and mismatch !!!\n'
                print error_message
                reportfile.write(error_message)
            # Mandatory fields check
            empty_fields = []
            for i in range(len(mandatory_fields)):
                start_index = start_index_list[i]
                end_index =start_index + field_length_list[i]
                field_value= line[start_index:end_index]
                if (field_value.strip() == ''):
                    field_name = mandatory_fields[i]
                    empty_fields.append(field_name)
            if len(empty_fields) >0 :    
                failed_number = failed_number+1
                if failed_number < 100:
                    error_message = 'In line '+str(line_num) +', empty fields:'+str(empty_fields) +'\n'
                    reportfile.write(error_message)
                    if failed_number < 10:
                        print error_message
            line_num = line_num+1
        if failed_number >0:
            total_info = str(failed_number)+' lines have empty mandatory fields'
        else:
            total_info = 'all pass, no line has empty mandatory fields'
        error_message ='Total '+str(line_num-1) +' lines, and '+total_info+'.\n'
        print error_message
        reportfile.write(error_message)
    reportfile.close()
    infile.close()

	

