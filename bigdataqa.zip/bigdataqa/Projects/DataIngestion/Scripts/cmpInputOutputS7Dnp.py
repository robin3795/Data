#!c:/Python27/python.exe
'''
In summary the target of this script is to compare the input and output data, based on
input and output configuration excel files.
So there are 5 steps/functions: 1.check input excel, 2.check output excel, 3.compare input output excel,
4.check input data, 5.check output data, 6.compare input output data.
step1 or 2 can be run independently, but they are prerequisite of step3
the same way, step4 need step1; step5 need step2; 
step6 need steps 1, 2, 3, 4, 5 are done/run

Currently the script can process two types of input file: fixed length input, field delimited input,
 based on the whether there is a "length" attribute in input excel
Output is  fixed length file.
Script will compare the columns from based on deninition of the input and output config  file,
Row number is supposed to be the same for input and output data

When run each functions of the script, when mismatch found, 
other than failed the test, it will write the mismatch to a report file.

According to the current business logic, the length of each column of input and output may not be 
the same, the script will handle it with following logic when happens:
When input column length < output column length , spaces will be added in the input to match output column length.
When input column length > output column length, left of the input(spaces) is truncated to match the output length.
In either case output column length mentioned in the output configuration file should be respected by the actual data element.
(No character will be truncated except spaces)

For field delimited file:
Script will recognize comma, as delimite.
When checking, script allow having the double quote pair "ABC",  or no having double quote pair: ABC, as value in each column.
But if there is only one quote: "ABC,   or   ABC", the script will report it as a defect. 

For pattern as " , "  (a comma in the double quote) in the input data file, this new version of script add a feature to recognize this pattern,
 and treat it as one string, will not split it into two columns by the delimiter sign comma , that is an excemption happens like:
a,b,c, "1055, rue Louis-Marchand", 1,2,,,,
So the "1055, rue Louis-Marchand" will be treated as one column (in fact it is the address1). This version of script fix this. 

In Sprint4 will receive both fixed length and field delimited files in both input and output configure and data files

In Sprint5 the script will retrieve the configure from excel, instead of from config xml files, to define the excel file in this way:
ExcelConfigFile = r'C:\work\Country_Name_Scan\Sprint5\Data\GFF_TO_GFF_Mapping.xlsx'
To define the sheet name, like:
readOutputExcel(excelconf,'Output_GFF')
readInputExcel(excelconf,'Input_GFF_Version5')
'''

from checkZeroKbFile import *
import time
import csv
import os
import os.path
import xml.etree.ElementTree as ET
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import re
import xlrd

global inputdict
global inputset
global inputlist
global input_index

global outputdict
global outputset
global outputlist
global output_index
global fixlen
global fixlenOutput
global sharedset
global reportfile

timestr = time.strftime('%Y%m%d_%H%M%S')
f_handler = open(r'C:\work\Country_Name_Scan\Sprint7\Results\out'+timestr+'_.log', 'w')
sys.stdout = f_handler



def check_input_xml(inputxml, report):
    inputtree = ET.parse(inputxml)
    inputroot = inputtree.getroot()
    #print '====Begin Check Input xml=========='
    global fixlen           
    global inputdict
    inputdict = {}
    global inputlist
    inputlist = []
    global input_index
    input_index = []
    i = 0 #index order for each column of input xml
    for child in inputroot:
        #print child.tag, child.attrib  
        name = child.attrib.get('name') 
        length = child.attrib.get('length')
        #print name, length
        if (length == None) or (length == ''):
            #print'field delimited input file'
            fixlen = 0
            inputdict[name]=i
            inputlist.append(name)
            input_index.append(i)            
        else:
            #print'fixed length input file' 
            fixlen = 1             
            try:    
                dlength= int(length)
                sl = [dlength, i]            
                inputdict[name]= sl
                inputlist.append({name:dlength})
                input_index.append(dlength)
            except ValueError:
                #print 'Input Error! This length in input xml is not a valid int length!' + name  
                global reportfile
                reportfile = report
                fileref = open(reportfile, 'a')
                fileref.write('Input Error! This length in input xml is not a valid int length!' + name +  '\n')
                fileref.close()
        i += 1
    #print
    #print 'input list:'
    #print inputlist
    #print  	
    #print 'inputdict:'
    #print inputdict
    #print  	
    inlist = inputdict.keys()
    #print'inlist'
    #print inlist
    #print  		
    global inputset
    inputset = set(inlist)
    #print'inputset:'
    #print inputset
    #print
    #print 'input index:'
    #print input_index
    #print 'Total rows in input xml:' + str(i)
            
    
def check_output_xml(outputxml, report):    
    outputtree = ET.parse(outputxml)
    outputroot = outputtree.getroot()
    #print 
    #print '====Begin Check Output xml=========='
    global fixlenOutput
    global outputdict
    outputdict = {}
    global outputlist
    outputlist = []
    global output_index
    output_index = []
    j = 0
    for child in outputroot:
        #print child.tag, child.attrib  
        name = child.attrib.get('name') 
        length = child.attrib.get('length')
        value = child.attrib.get('value')
        #print name, length, value
        if (length == None) or (length == ''):
            #print'field delimited output file'
            fixlenOutput = 0
            outputdict[name]=j
            outputlist.append(name)
            output_index.append(j)            
        else:
            #print'Fix length output'
            fixlenOutput = 1
            
            try:    
                    dlength= int(length)
                    sl = [dlength, j]                        
                    outputdict[name]= sl
                    #print outputdict[name]
                    outputlist.append({name:dlength})
                    output_index.append(dlength)
                
            except ValueError:
                    #print 'Output Error! This length in output xml is not a valid int length!' + name 
                    global reportfile
                    reportfile = report	
                    fileref = open(reportfile, 'a')
                    fileref.write('Error! This length in output xml is not a valid int length!' + name  + '\n')
                    fileref.close()
        
        j += 1
    
    #print 'output list:'
    #print outputlist
    #print    
    #print 'outputdict:'
    #print outputdict
    #print	
    outlist = outputdict.keys()
    #print'outlist:'
    #print outlist
    #print	
    global outputset
    outputset = set(outlist)
    #print'outputset:'
    #print outputset
    #print	
    #print 'output index:'
    #print output_index
    #print 'Total rows in output xml:' + str(j)

def compare_input_output_conf(report):
    #print '\n====Begin compare Input Output configuration=========='
    global reportfile
    reportfile = report
    fileref = open(reportfile, 'a')
    fileref.write('Input and Output config Comparison Report:' + '\n')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Following config length mismatch ' + '\n')
    fileref.write('Output configure file mismatch with the input configure file at\n')
    fileref.write("[Column name, Output config length, Input config length ]" + '\n')
    fileref.write('-------------------------------------------------' + '\n'*2)
    #print    
    #print 'shared names set:'
    global sharedset
    sharedset = inputset & outputset
    #print'shared columns in output and input config:'
    #print sharedset
                
    for e in sharedset:
        #print e         ,
        #print 'Out config', outputdict[e]            ,
        #print 'In config', inputdict[e]
        if (fixlen == 1) and (fixlenOutput == 1):    #Until both input and output are fix length, it make sense to compare length
            if outputdict[e][0] != inputdict[e][0]:
                #print'Different length between Output configure  with Input configure  file!'
                #print outputdict[e][0]
                #print inputdict[e][0] 
                fileref.write( e + ' , ' + str(outputdict[e][0]) + ' , ' + str(inputdict[e][0]) +'\n')
                if  outputdict[e][0] > inputdict[e][0]:                   
                    #print 'Output length great than input length in config that is acceptable.' 
                    pass                    
        #print
    #print    
    fileref.close()

def splitbylen(a, c):
    '''
    #b = [a[0:2], a[2:6], a[6:24], a[24:38], a[38:52], a[52:54]]
    a ='There is Something in the river and also in the water need to be split                             '
    c = [2,4,18,14,14,2]    
    '''
    b = []
    i = 0
    for x in c:
        b.append(a[i:i+x])
        i += x
    #print(b)
    return b
    
    

def check_output_data(outputfile, report, hasHeader = 0):
    #print '====Begin check Output data=========='
    outlistoflist = []
    global reportfile
    reportfile = report
    fileref = open(reportfile, 'a')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Fields Comparison Report:' + '\n')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Following Output Fields Mismatch, rows and columns counted from 0,0: ' + '\n')
               
    fileref.write("output data file mismatch with the output configure file at \n")
    fileref.write("[Row No., Column No., Output config length, Real length in output data file, Column name]" + '\n')
    fileref.write('-------------------------------------------------' + '\n'*2)
    
    '''
    #print'outputlist:'
    #print outputlist
    #print outputlist[0].keys()
    #print outputlist[0].keys()[0]
    #print outputlist[0].values()
    #print outputlist[0].values()[0]
    '''
    f = open(outputfile,'r')
    filelines=f.readlines()
    #print'config output index:'
    #print output_index

    hh = int(hasHeader)
    #print'hasOutputHeader is:', hh
    #hh = 0  # for insurance input data, no columns names row.
    #hh = 1	# for LVS  data file has first row as column names row, bypass first row. 
    for n in range(hh,len(filelines)):    
    #for n , line in enumerate(f):
        line = filelines[n]
        #print'---- iterate rows of output data ----'
        line = line.rstrip('\n')       
        #print 'row: ' + str(n)+' has ' + str(len(line)) +' length in output file'
        #print line 
        if fixlenOutput == 1: 
            #print'fixed length Output file In Check output data'           
            list1 = splitbylen(line,output_index)            			
        else:
            #print'field delimited output file when check_output_data'
            p = re.compile(r'(".*?,.*?")')
            nl =  p.findall(line) 
            ##print'len of foundall list:' ,len(nl)
            for word in nl:
                #print 'word is:',word
                word2 = re.sub(',', r'CommaFoundInQuote',word)     
                #print 'sub word2 is:',word2   
                #print 'line:',line   
                #print    
                line = line.replace(word,word2)
                #print'line2: ',line  
            #print 'line:', line
            list1 = line.split(',')
            list1 = map(lambda x :  x.replace('CommaFoundInQuote',','), list1)
            #print'out list1first', list1
            for i in range (len(list1)):
                list1[i] = removequote(list1[i],n,i)
        #print 'output data file totally has many columns as:'     
        #print len(list1)
        #print ' now second list1 is .....'
        #print list1
        outlistoflist.append(list1)
        #print 'NOW ROW2',outlistoflist
        if len(list1)!= len(output_index):
            #print'Size mismatch between output data file  with the output configure file!'
            #print str(len(list1))+' : ' +str(len(output_index))
            fileref.write('\nSize Mismatch between output data file  with the output configure file!\n')
            fileref.write(str(len(list1))+' : ' +str(len(output_index)))
                
        for i in range(len(list1)):
            if fixlenOutput == 1:    #Until fix length it make sense to compare length            
                #print 	'output data length: ' + str( len(list1[i])) + ' | output config length: ' + str(output_index[i])  
                if len(list1[i]) != output_index[i]: 
                    #print 'output data file mismatch length with the output configure file at row:', n , ' column:', i ,' column name:',outputlist[i].keys()[0]
                    #print                
                    fileref.write(' row:' + str(n) +', column:' +str(i)+ ' , '+str(output_index[i])\
                    + ' , ' + str(len(list1[i])) + ' , ' + outputlist[i].keys()[0] +'\n')                
                #print 'Output value in data:',(list1[i]) 
            else:
                #print'fixlenOutput file'
                pass                
        #print
      
    #print
    #print'Total output data row: ',  n	
           
    fileref.close() 
    f.close()
    return outlistoflist
    
def removequote(string,n,i):
    string = string.strip()
    #if string.startswith('"') and string.endswith('"'): 
        #string = string[1:-1]
    
    if string.startswith('"'):
        if string.endswith('"'):
            #print'has both quotes'
            string = string[1:-1]        
        else:
            #print'Has Start quote but No end quote in row:' + str(n) + ' ,in col:' + str(i) + ' ,Value:' + string
            fileref = open(reportfile, 'a')
            fileref.write('Has start quote but No end quote in row:' + str(n) + ' in col:' + str(i) + 'Value:' + string + '\n')
            fileref.close()
    else:
        if string.endswith('"'):
            #print'Has End quote but No start quote in row:' + str(n) + ' ,in col:' + str(i) + ' ,Value:' + string
            fileref = open(reportfile, 'a')
            fileref.write('Has end quote but No start quote in row:' + str(n) + ' in col:' + str(i) + 'Value:' + string + '\n')
            fileref.close() 
        else:
            #print'No quote at all'
            pass
        
    string = string.strip() #For field delimited file don't worry about spaces
    return string
    
def check_input_data(inputfile, report, hasHeader = 0):
    #print '====Begin check Input data=========='
    inlistoflist = []
    global reportfile
    reportfile = report
    fileref = open(reportfile, 'a')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Fields Comparison Report:' + '\n')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Following Input Fields Mismatch, rows and columns counted from 0,0: ' + '\n')            
    
    fileref.write("Input data file mismatch with the input configure  at \n")
    fileref.write("[Row No., Column No., Input config length, Real length in input data file, Column name]" + '\n')
    fileref.write('-------------------------------------------------' + '\n'*2)
      
    f = open(inputfile,'r')
    filelines=f.readlines()
    hh = int(hasHeader)
    #print'hasInputHeader is:', hh
    #hh = 0  # for insurance input data, no columns names row.
    #hh = 1	# for LVS input data file has first row as column names row, bypass first row. 
    for n in range(hh,len(filelines)):
        line = filelines[n]
        line = line.rstrip('\n')          
        #print 'row: ' + str(n)+' has ' + str(len(line)) +' length in Input file'
        #print line
        
        #print'config input index, and its size:'+ str(len(input_index))
        #print input_index
        #print len(input_index)
        if fixlen == 1: 
            #print'fixed length file'           
            list1 = splitbylen(line,input_index)        
        else:
            #print'field delimited file'
            p = re.compile(r'(".*?,.*?")')
            ##p = re.compile(r'(".*?|.*?")')
            nl =  p.findall(line) 
            #print'len of foundall list:' ,len(nl)
            for word in nl:
                #print 'word is:',word
                word2 = re.sub(',', r'CommaFoundInQuote',word)
                ##word2 = re.sub('|', r'CommaFoundInQuote',word)                 
                #print 'sub word2 is:',word2   
                #print 'line:',line   
                #print    
                line = line.replace(word,word2)
                #print'line2: ',line  
            #print 'line:', line
            
            list1 = line.split(',')  # this is used for field delimited file ',' or '|' etc.
            ##list1 = line.split('|')  # this is used for field delimited file ',' or '|' etc.
            #list1 = map(removequote, list1)
            list1 = map(lambda x :  x.replace('CommaFoundInQuote',','), list1)
            ##list1 = map(lambda x :  x.replace('CommaFoundInQuote','|'), list1)
            print'list1first', list1
            for i in range (len(list1)):
                list1[i] = removequote(list1[i],n,i)
            
        #print 'input data file totally has many columns as:'     
        #print len(list1)
        #print ' now list1 is .....'
        #print'list1second', list1
        inlistoflist.append(list1)
        #print 'NOW ROW',inlistoflist
        
        if len(list1)!= len(input_index):
            #print'Size mismatch between input data file  with the input configure file!'
            #print str(len(list1))+' : ' +str(len(input_index))
            fileref.write('Size mismatch between input data file  with the input configure file!\n')
            fileref.write(str(len(list1))+' : ' +str(len(input_index)))
             
        for i in range(len(list1)):           
            #print 'total columns from input config: ',input_index[i]
            if fixlen == 1: 
                #print 'in data length: ', len(list1[i])
                #print 'input config length: ',input_index[i]
                #print 	'in data length: ' + str( len(list1[i])) + ' | input config length: ' + str(input_index[i])
                if len(list1[i]) != input_index[i]:
                    #print 'input data file mismatch with the input configure file at row:', n , ' column:', i ,' column name:',inputlist[i].keys()[0]
                    #print 
                    
                    fileref.write(' row:' + str(n) +', column:' +str(i)+ ' , '+str(input_index[i])\
                     + ' , ' + str(len(list1[i])) + ' , ' + inputlist[i].keys()[0] +'\n')
            else:
                #print ' field delimeted data when check input data' 
                pass
                    
            
            #print 'Input value in data:', (list1[i])            
        #print

    #print'Total input data row: ',n        
    #print 

    fileref.close() 
    f.close()
    return inlistoflist


def Compare_input_ouput_data(listi, listo):
    #print'Begin comparing input and output data...'
    #print 'fixlen:', fixlen
    #print'fixlenOutput:',fixlenOutput
    global reportfile
    t = 0 # total mismatch found
    fileref = open(reportfile, 'a')
    fileref.write('------------------------' + '\n'*2)
    fileref.write('Fields Comparison Report:' + '\n')
    fileref.write('------------------------' + '\n'*2)
    #fileref.write('Following Input and Output Fields Mismatch, rows and columns counted from 0,0: ' + '\n')
    
    r1 =  len(listi)           
    r2 =  len(listo)
    #print'row of input data:'
    #print r1 
    #print'row of output data:'
    #print r2    
    matchedinput = 0
    #if r1 != r2:
        #print'Mismatch found, input : output data files rows number are not equal ' + str(r1)+' :  ' + str(r2)        
        #fileref.write('Mismatch found, input : output data files rows number are not equal ' + str(r1)+' :  ' + str(r2) + '\n')
        #pass        
    #else:
    if 1 == 1:
        fileref.write("Input data file mismatch with the output data file at \n")
        fileref.write("[Row No., Column Name, Input Column No., Output Column No., Input data value, Output data value]" + '\n')
        fileref.write('-------------------------------------------------' + '\n'*2)
        for i in range(r1):# iterate each row of input and output data
            fileref.write('====================Start input row number:===========================' +  str(i) +'\n'*2)
            #print(' input row number: ' + str(i))
            #for e in sharedset:
            for ii in range(r2): # disorder of two 
                passflag = 1# count if this one rowinput pass match the one row output
                #print'output loop ii: ',ii
                fileref.write('----------------Iterate Output row number:----------------' +  str(ii) +'\n'*2)
                for e in sharedset:
                    #print e         ,
                    #print 'In config', inputdict[e]            ,
                    #print 'Out config', outputdict[e]               
                    #for ii in range(r2): # disorder of two                
                    if fixlen == 1 : 
                        ci = inputdict[e][1]
                        #print 'ci:',ci
                        valin = listi[i][inputdict[e][1]]
                        if fixlenOutput == 1:
                            ol = outputdict[e][0]
                            il = inputdict[e][0]
                            valout = listo[ii][outputdict[e][1]]  #valout = listo[ii][outputdict[e][1]]                                                   
                            if il < ol:
                                #print'Input config defined a length  smaller < than Output config'
                                #print 'input len: ' +str(il) +':'+ 'output len: ' + str(ol);    
                                #fileref.write( e + ' , ' + str(outputdict[e][0]) + ' , ' + str(inputdict[e][0]) +'\n')
                                sl = ol - il
                                #print str(sl) + ' spaces need to make up from left: '
                                ###valin = ' '*sl + valin
                                valin = valin + ' '*sl
                                print len(valin)
                                
                            elif il >ol:                                                 
                                #valin = listi[i][inputdict[e][1]]
                                #print 'Input config defined a length great > than Output config' 
                                #print 'input len: ' +str(il) +':'+ 'output len: ' + str(ol);
                                
                                valin = valin.lstrip() # trunate spaces from the left of input val
                                dl = len(valin)
                                #print'length of valin:'+str(dl)
                                sl = ol - dl
                                #print str(sl) + ' Spaces need to make up from left: '
                                valin = ' '*sl + valin
                                #print len(valin)                               
                            else:                                                                                                             
                                #print'same length in output config and input config'
                                pass                       
                            co = outputdict[e][1]
                        else: #fixlenOutput != 1 
                            #print'fixlen input but Not fixlenOutput'                        
                            co = outputdict[e] 
                            valout = listo[ii][outputdict[e]]#valout = listo[i][outputdict[e]]
                            valin = valin.strip()                                                 
                            valout = valout.strip() # field delimited file do not worry spaces
                                
                    else: # fixlen != 1 
                        ci = inputdict[e]
                        
                        print 'i',i                       
                        print listi[i][0]
                        print 'ci', ci   
                        #print listi[i][0][1]
                        #print 'list[i]',listi[i]
                        print listi[i]
                        print'e',e
                        valin = listi[i][inputdict[e]]
                        if fixlenOutput == 1: 
                            co = outputdict[e][1]
                            valout = listo[ii][outputdict[e][1]]#valout = listo[i][outputdict[e][1]]
                        else:   #fixlenOutput != 1
                            co = outputdict[e]
                            valout = listo[ii][outputdict[e]]#valout = listo[i][outputdict[e]]

                        valin = valin.strip()                                                 
                        valout = valout.strip() # field delimited file do not worry spaces 
                      #end of fixlend == 1 else 
                #valout = listo[i][outputdict[e][1]]

                    #print 'in data col:' + str(ci)        ,
                    #print 'out data col:' + str(co)
                    #print 'in data:' + valin #+'END'
                    #print 'ot data:' +valout #+'END'
                    
                    #print 'input data value: ' + valin + ' output data value: ' + valout
                    if valin != valout:
                        passflag = 0
                        t = t+1
                        #print'Mismatch found! Input data value Not match output data value!' 
                       # fileref.write(' row:' + str(i) + ', input column No:' +str(ci)+ ', input column No:' + str(co)\
                       # + 'input data: ' + valin + ' output data: ' +valout + '\n')
                        fileref.write(str(i)+','+e+','+str(ci)+','+str(co)+','+valin+','+valout+'\n')
                    #pass 
                    else:
                        ##print'Found match!'
                        pass
                        #passflag = 1                    
                    #print
                if passflag == 1:
                    matchedinput = matchedinput+1
                    ##print'Found match output row!'+str(i)+','+ e+','+str(ci)+','+str(co)+','+valin+','+valout
                    #fileref.write('Found match output row!'+ str(i)+','+e+','+str(ci)+','+str(co)+','+valin+','+valout+'\n'
                    #print'Found match output row! Input row:'+str(i)+', Output row:'+ str(ii)
                    fileref.write('Found match output row! Input row:'+ str(i)+', Output row:'+str(ii)+'\n') 
                    
            #print
        fileref.write('-------------------------------------------------' + '\n'*2)			
        fileref.write('Total mismatch found: ' + str(t) +'\n')
        fileref.write('Total Matched row found: ' + str(matchedinput) +'\n')
        #print 'Total Matched row found: ' + str(matchedinput) +'\n'
	fileref.close()    
    
def open_excel(file = 'file.xls'):
    try:
        data = xlrd.open_workbook(file)
        return data
    except Exception, e:
        #print str(e)
        pass
        
def readInputExcel(file,sn):
    #print 'file:', file, ' sn:',sn    
    data = open_excel(file)               
    table = data.sheet_by_name(sn)
    global input_index
    global inputdict
    global inputlist
    input_index = []
    inputdict = {}
    inputlist = []
    LengthCol = 1
    LengthRow = 0
    nrows = table.nrows
    for i in range(nrows ):
        #print table.row_values(i)
        if fixlen == 1 :  
            for j in range(len(table.row_values(i))):
                #if table.row_values(i)[j] == 'Length':            
                if (table.row_values(i)[j] == 'Length') and (table.row_values(i)[j+1] == 'Column'):
                    LengthCol = j
                    LengthRow = i
                    #print'found Length at row, col:',LengthRow,LengthCol
                    break
                else:
                    ##print 'not matched Length Column Header In'
                    pass
        else:
            #print 'not fixlen input, read excel config with no Length!'
            for j in range(len(table.row_values(i))):
                if table.row_values(i)[j] == 'Column':            
                    LengthCol = j
                    LengthRow = i
                    #print'found Column at row, col:',LengthRow,LengthCol
                    break
                else:
                    ##print 'not matched Length Column Header In'
                    pass
    n = LengthRow+1 #LengthRow is supporsed as a header row
    for i in range(n,nrows):                
        #dlength = int(table.row_values(i)[LengthCol])
        #name = table.row_values(i)[(LengthCol+1)]#Length , Column
        if fixlen == 1 :  
            name = table.row_values(i)[(LengthCol+1)]#Length , Column        
            dlength = int(table.row_values(i)[LengthCol])        
            sl = [dlength, i-1]#sl = [dlength, i]
            inputdict[name]= sl
            inputlist.append({name:dlength})
            input_index.append(dlength)
        else:    
            name = table.row_values(i)[(LengthCol)]#Length , Column        
            inputdict[name]= i-1
            inputlist.append(name)
            input_index.append(i-1)
                
    #print'-----------------------'
    #print 'input list:'
    #print inputlist
    #print 'input dict:'
    #print inputdict
    #print 'input index:'
    #print input_index
    inlist = inputdict.keys()
    global inputset
    inputset = set(inlist)

def readOutputExcel(file,sn):
    #print 'file:', file, ' sn:',sn    
    data = open_excel(file)               
    table = data.sheet_by_name(sn)
    global outputdict
    global outputlist
    global output_index
    output_index = []
    outputdict = {}
    outputlist = []
    LengthCol = 1
    LengthRow = 0
    nrows = table.nrows
    for i in range(nrows ):
        #print table.row_values(i)
        for j in range(len(table.row_values(i))):
            #if table.row_values(i)[j] == 'Length':
            if (table.row_values(i)[j] == 'Length') and (table.row_values(i)[j+1] == 'Column'):
                LengthCol = j
                LengthRow = i
                #print'found Length at row, col:',LengthRow,LengthCol
                break
            else:
                ##print 'not matched Length Column Header Out'
                pass

    n = LengthRow+1
    for i in range(n,nrows):                

        dlength = int(table.row_values(i)[LengthCol])
        sl = [dlength, i-1]#sl = [dlength, i]
        name = table.row_values(i)[(LengthCol+1)]#Length , Column
        outputdict[name]= sl
        outputlist.append({name:dlength})
        output_index.append(dlength)
                
    #print'-----------------------'
    #print 'output list:'
    #print outputlist
    #print 'output dict:'
    #print outputdict
    #print 'output index:'
    #print output_index
    outlist = outputdict.keys()
    global outputset
    outputset = set(outlist)


#def start_compare_data(inputfile1,outputfile1,report,excelconf,inputHasHeader=0,outputHasHeader=0):
#def start_compare_data(inputfile1,outputfile1,report,excelconf,configS1, configS2, inputHasHeader=0,outputHasHeader=0):
def start_compare_data(inputfile1,outputfile1,report,excelconf,configS1, configS2, inputHasHeader=0,outputHasHeader=0,fixle = 1, fixlenOut = 1 ):
    global fixlen
    #fixlen = 1
    #fixlen = 0
    fixlen = int(fixle)
    global fixlenOutput
    #fixlenOutput = 1
    fixlenOutput = int(fixlenOut)
    global reportfile
    reportfile = report

    #print inputfile1,'\n',outputfile1,'\n',report,'\n',excelconf,'\n',inputHasHeader,'\n',outputHasHeader,'\n', fixlen, '\n', fixlenOutput, '\n'
       
    #readOutputExcel(excelconf,'Output_GFF')
    readOutputExcel(excelconf,configS2)
    #print '============================================'
    #print
    #print
    
    #readInputExcel(excelconf,'Input_GFF_Version5')
    readInputExcel(excelconf,configS1)
    
    compare_input_output_conf(report)
    
    listinput = check_input_data(inputfile1,report,inputHasHeader)
    listoutput = check_output_data(outputfile1, report,outputHasHeader)
    Compare_input_ouput_data(listinput, listoutput)  
    
def Append_Files(fn,baseDir,newFile):		
    filenames = map (lambda x : baseDir + x  , fn)
    with open(newFile, 'w') as outfile:
        for i in range(len(filenames)):
           with open(filenames[i]) as infile:
               for line in infile:
                   outfile.write(line)

def Join_Directory(baseDir, newFile): 
    list_dirs = os.walk(baseDir) 
    for root, dirs, files in list_dirs: 
        Append_Files(files,baseDir, newFile)


    
if __name__ == '__main__':   
    timestr = time.strftime('%Y%m%d_%H%M%S')
    report = r'C:\work\Country_Name_Scan\Sprint7\Results\report_'+timestr+'.txt' 
    
    #ExcelConfigFile = r'C:\work\Country_Name_Scan\Sprint7\Data\SilverLayerTables.xlsx'
    ExcelConfigFile = r'C:\work\Country_Name_Scan\Sprint7\Data\GFF_TO_GFF_Mapping.xlsx'    
    #inputConfigSheet = 'Input_GFF_Version5' 
    #inputConfigSheet = 'Input_GFF_version4'
    #inputConfigSheet = 'Input_TOM_FRANCE_v20'
    inputConfigSheet = 'party_communication'
    #inputConfigSheet = 'Sheet7'
    outputConfigSheet = 'Output_GFF'	
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\729\sftp_20160810102314_6_Clnt.DAT'
    #inputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\729\729_20160518180354_6_Clnt.DAT'
	
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\536\20160916102012_6_Clnt.DAT'
    #inputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\536\Input\536_20160912-114119_6_Clnt_V5.DAT'   
    #outputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\536'
    #inputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\536\Input' 


    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\110\110gff_2012_05_14out.DAT'
    #inputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\110\Input\110gff_2012_05_14.DAT' 
    #outputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\100'
    #inputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\100\Input'    
    
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint6\Data\Baseline\776\776_20160803153925_6_Clnt.DAT'
    #inputfile1 = r'C:\work\Country_Name_Scan\Sprint6\Data\Baseline\776\Input\20131027080776_6_Clnt_old.DAT'        
    #outputdir = r'C:\work\Country_Name_Scan\Sprint6\Data\Baseline\776'
    #inputdir = r'C:\work\Country_Name_Scan\Sprint6\Data\Baseline\776\Input'
    
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\609\20160920115918_6_Clnt.DAT'
    #inputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\609\Input\20160915000512_6_Clnt.DAT'        
    #outputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\609'
    #inputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\609\Input'
    
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810\part-00000.DAT'
    #inputfile1 = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810\Input\810_communication.csv'        
    #outputdir = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810'
    #inputdir = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810\Input'
    
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810\part-00000.DAT'
    outputfile1 = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810\out1.DAT'
    inputfile1 = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810\Input\810_communication.csv'        
    outputdir = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810'
    inputdir = r'C:\work\Country_Name_Scan\Sprint7\Data\Baseline\810\Input'
    
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint6\Data\Baseline\630\20161004211539_6_Clnt.DAT'
    #inputfile1 = r'C:\work\Country_Name_Scan\Sprint6\Data\Baseline\630\Input\20161004111630_6_Clnt.DAT'     
    #outputdir = r'C:\work\Country_Name_Scan\Sprint6\Data\Baseline\630'
    #inputdir = r'C:\work\Country_Name_Scan\Sprint6\Data\Baseline\630\Input'
    
    ##ZeroKbFilecheck1(inputdir,outputdir,outputfile1,report)
    ##ZeroKbFilecheck2(inputdir,outputdir,outputfile1,report)
    #outputxml = r'C:\work\Country_Name_Scan\working\Data\Baseline\609\insurance_v5_output_config.XML'
    #inputxml = r'C:\work\Country_Name_Scan\working\Data\Baseline\609\insurance_v5_input_config.XML'
    #start_compare_data(inputfile1,outputfile1,report,ExcelConfigFile,inputConfigSheet,outputConfigSheet,0,0)
    
    start_compare_data(inputfile1,outputfile1,report,ExcelConfigFile,inputConfigSheet,outputConfigSheet,1,0,0,1)
    #start_compare_data(inputfile1,outputfile1,report,ExcelConfigFile,0,0)
    #start_compare_data(inputfile1,outputfile1,report,inputxml,outputxml,0,0)    
    
    #outputfile1 = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\800\20160805141829_6_Clnt.DAT' #zero kb
    #inputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\800\Input'
    #outputdir = r'C:\work\Country_Name_Scan\Sprint5\Data\Baseline\800'
    




        
