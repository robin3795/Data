# Data
PPT or PDF files for July 4th 
Topics: Big Data, ETL, Robot Automation Testing and Python
Some interesting pictures https://github.com/jstpcs/lnxpcs Linux pic and Test Pic
